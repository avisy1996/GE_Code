#ifndef _CALC_SUM_H
	#define _CALC_SUM_H
#endif
#define MAX 100
int get_sum (char *, int *);
