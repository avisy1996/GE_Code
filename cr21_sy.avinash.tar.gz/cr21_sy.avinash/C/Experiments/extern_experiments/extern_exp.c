#include <stdio.h>
#include "head.h"

int a = 10;
int main()
{
	printf("\na = %d", a);

}
