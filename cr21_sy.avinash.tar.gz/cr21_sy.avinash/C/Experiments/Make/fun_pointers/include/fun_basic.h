#ifndef _FUN_BASIC_H
#define _FUN_BASIC_H


#endif
