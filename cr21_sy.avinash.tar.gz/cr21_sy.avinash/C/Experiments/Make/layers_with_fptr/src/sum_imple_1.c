#include <stdio.h>
#include "layers_with_fptr.h"

int sum(int a, int b)
{
	return (a + b);
}

/**
  * @fun : sum_example_1
  * @brief : This function illustrates usage of function pointers; 
  *		and function pointer is used and called similar to a normal
  *		function all;
  */

void sum_example_1 (int a, int b)
{
	int (*sum_fun_ptr)(int, int);
	sum_fun_ptr = sum;
	printf ("%s: Sum (%d, %d) = %d\n", __func__, a, b, sum_fun_ptr(a, b));
}

void init_sum_module ()
{
	register_sum_operation(sum_example_1);
}
