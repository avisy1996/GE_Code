/* Program to illustrate the basic usage of function pointers */

#include <stdio.h>
#include "layers_with_fptr.h"

sum_fun_ptr registered_sum_fun = NULL;

void register_sum_operation (sum_fun_ptr sum_fun)
{
	registered_sum_fun = sum_fun;
}

void do_sum (int a, int b)
{
	registered_sum_fun(a, b);
}

int main (void)
{
	int x = 5, y = 10;

	init_sum_module();
	do_sum(x, y);
	return 0;
}
 
	
