#ifndef _CALC_H
#define _CALC_H

int add(int, int);
int sub(int, int);
int mul(int, int);
int division(int, int);

#endif
