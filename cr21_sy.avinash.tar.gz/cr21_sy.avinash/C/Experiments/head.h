extern int a;

