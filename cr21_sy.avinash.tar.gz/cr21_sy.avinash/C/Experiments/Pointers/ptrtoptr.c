#include <stdio.h>
int main(void)
{
	int arr[3] = {1,2,3};
	int (*ptr)[3];
	ptr = &arr;

	printf ("\narr = 0x%08x : 0x%08x\t&arr = 0x%08x : 0x%08x\n", arr, *arr, 
			&arr, *(&arr));	
	printf ("arr + 1 = 0x%08x : 0x%08x\n", arr + 1, *arr + 1);
	printf ("ptr = 0x%08x : 0x%08x\t&ptr = 0x%08x : 0x%08x\n", ptr, *ptr, 
			&ptr, *(&ptr));
	printf ("*ptr = 0x%08x : 0x%08x\t&ptr + 1 = 0x%08x : 0x%08x\n", *ptr, 
			**ptr, ptr + 1, *(ptr + 1));
	printf ("\n(*ptr + 0) = 0x%08x\t*(*ptr + 0) = 0x%08x\n", (*ptr + 0), 
			*(*ptr + 0)); 
	printf ("(*ptr + 1) = 0x%08x\t*(*ptr + 1) = 0x%08x\n", (*ptr + 1), 
			*(*ptr + 1)); 
	printf ("(*ptr + 2) = 0x%08x\t*(*ptr + 2) = 0x%08x\n", (*ptr + 2), 
			*(*ptr + 2));
	printf ("(*ptr + 3) = 0x%08x\t*(*ptr + 3) = 0x%08x\n", (*ptr + 3), 
			*(*ptr + 3)); 
	return 0;
}
