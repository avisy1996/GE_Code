#include <stdio.h>

int main(void)
{
    char str[10] = "xyz";
  //  char *ch = 'a';
    char *name = "abc";
    printf("Len str = %d", strlen(str));
   // printf("Len ch = %d", strlen(ch));
    printf("Len name = %d", strlen(name));

    return 0;
}
