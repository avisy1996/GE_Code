/*#include <stdio.h>
			
   	int main( )
     { 
	const int *p ;
	int k = 10 ; 
    	p =&k ; 
    	*p = 20 ; 
     printf("\n %d", k );
	return 0;
	}*/
#include <stdio.h>
	int main (void)
	{
		int a[] = { 1, 2, 3, 4}; 
		int *p = (&a + 1) ; 
		printf ("ans = %d, %d" , *(a + 1),  *(p - 1) );
		return 0;
	}
