#include <stdio.h>

int main (void)
{
	int i = 0;
	int arr[3] = {10, 20, 30};
	
	typedef int (*test)[];
	test ptr;

	ptr = &arr;

	while (i < 3) {
		printf ("%d ",*(*ptr + i));
		i ++;
	}
	return 0;
}
