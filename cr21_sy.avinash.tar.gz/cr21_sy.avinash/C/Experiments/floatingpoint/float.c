#include <stdio.h>
int main()
{
//	float a = -0.5;
	printf ("Without : %d", 17 % 5);
	printf ("Without : %d", 17 & 4);
	printf("\n%d\n", strlen("avinash"));
	return 0;
}
