#include <stdio.h>

int main (void) 
{
	int a = 10;
//	int b = 10;
	a = a++;
	//b = a++;
	printf ("%d\n", a);
	return 0;
}
