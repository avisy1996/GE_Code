#include <stdio.h>

int x;
int *y;
//*y = "abc";
//char *y;
//y = "abc";
*y = &x; 
int main() {
	return 0;
}
