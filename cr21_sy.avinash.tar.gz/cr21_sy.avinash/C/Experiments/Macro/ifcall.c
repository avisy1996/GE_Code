#ifndef _STDIO_H
    #include <stdio.h>
#endif

#if CH == 1
    int main(void)
    {
        printf("CH = 1\n");
        return 0;
    }
#endif

#if CH == 2
    int main(void)
    {
        printf("CH = 2\n");
        return 0;
    }
#endif
