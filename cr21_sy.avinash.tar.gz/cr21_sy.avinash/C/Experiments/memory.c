#include <stdio.h>
int main (void)
{
	int a;
	printf ("A = %d\n", a);
	return 0;
}
