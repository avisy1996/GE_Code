#include <stdio.h>

int *p;

int main()
{
    *p = 12;
    
    return 0;
}
