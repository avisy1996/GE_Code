#include <stdio.h>

int main(void)
{
    int a = 20;
    if (a = 10)
        printf("a is 10\n");
    else 
        printf("a is not 10\n");
    return 0;
}
