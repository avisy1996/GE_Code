#include "bitwise_op.h"

unsigned int my_atoi(char *str)
{
    unsigned int res = 0;
	int sign = 1;
    
	if (*str == '+') {
        sign = 1;
        str ++;
    }
    if (*str == '-') {
        sign = -1;
        str ++;
	} 

    while (*str)
    {
        if(*str >= '0' && *str <= '9') {
            res = res * 10 + (*str - '0');
        }
        else {
            return NULL;
        }
        str ++;
    }
    res = res * sign;

    /*if (res < 0 || res > UINT_MAX) {
		return NULL;
    } */

    return res;
}
