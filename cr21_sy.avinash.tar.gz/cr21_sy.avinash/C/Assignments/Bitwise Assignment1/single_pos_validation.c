/*
	Positions are starting from zero.
*/

#include "bitwise_op.h"

#define NO_OF_BITS 32
#define LSB_BIT 0
#define FALSE 0
#define TRUE 1

unsigned int single_pos_validation (unsigned int s_pos)
{
	if (s_pos < NO_OF_BITS && s_pos >= LSB_BIT) {
		return TRUE;
	}
	
	return FALSE;
}
