#include "bitwise_op.h"
#include <stdlib.h>

int main(void)
{
    unsigned int s_num, d_num, res, count;
    int s_pos, d_pos, num;
    int ch;         //choice for switch case.
	int flag = 0;
	char *str;
	count = 0;
    
//    printf("1. Bit swap withing the number.\n2. Bit swap between two\
numbers.\n3. Copy n bits starting from s in 1st number at d in 2nd\
number.\n4. Toggle even and odd bits of number.\n5. Test and set a\
bit.\n6. Left and Right Rotate the bit.\n7. Left and Right Rotate\
the n bits.\n8. Count set and Clear bits\n9. Count Leading and\
Trailing set and Clear bits\n10. Set bits.\n11. invert bits\n12.\
macro get bits\n13. Set and Clear Rightmost and leftmost cleared\
and set bits\n14. Set, Clear and Toggle bits from s to d\n\
15. Maximum and minimum of two numbers\n"); 

	str = (char *)malloc(sizeof(char) * MAX);
#if 0	
	printf ("Enter your choice : ");
    
    if (fgets (str, MAX, stdin) == NULL) {
		printf ("Enter choice as integer!\n");
		exit (0);
	}	
	
	ch = atoi(str);
	printf ("%d\n", ch);
	if ((void*)ch == NULL) {
		printf ("Number is not valid integer!\n");
		exit (0);
	}

    switch (ch) {
    case 1:		/*****	bit_swap()	*****/
#endif	
#if 0
        printf("Enter the positive number = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str);

		printf("Enter source and destination index = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_pos = atoi(str);
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}
		d_pos = atoi(str);

		res = bit_swap(&s_num, s_pos, d_pos);
		if (res == SUCCESS) {
			display_binary_num (s_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}
//        break;
#endif
#if 0 
  //  case 2:		/*****	bit_swap_num()	*****/
        printf("Enter the 1st positive number = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str);

        printf("Enter the 2nd positive number = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		d_num = atoi(str);

		printf("Enter s_pos = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_pos = atoi(str);

        printf("Enter d_pos = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}
		d_pos = atoi(str);

        res = bit_swap_num(&s_num, &d_num, s_pos, d_pos);

		if (res == SUCCESS) {
			printf ("Source No:");
			display_binary_num (s_num);
			printf ("Destination No:");
			display_binary_num (d_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}
     //   break;
#endif
#if 0
    //case 3:		/*****	bit_copy()	*****/
        printf("Enter the 1st positive number = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str);

        printf("Enter the 2nd positive number = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		d_num = atoi(str);

		printf("Enter s_pos = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_pos = atoi(str);

        printf("Enter d_pos = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}
		d_pos = atoi(str);

        printf("Enter number of bits to copy = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}
		num = atoi(str);
 
        res = bit_copy(&s_num, &d_num, num, s_pos, d_pos);

		if (res == SUCCESS) {
			display_binary_num (s_num);
			display_binary_num (d_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}

      //  break;
#endif
#if 0 
//	case 4:		/***** bit_toggle()	*****/
        printf("Enter the positive number = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str); 
        
        res = even_bit_toggle(&s_num);
		if (res == SUCCESS) {
			printf("Even Bit Toggle = ");
			display_binary_num (s_num);
		}

		printf("Enter the positive number = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str); 

        res = odd_bit_toggle(&s_num);   
		if (res == SUCCESS) {
			printf("Odd Bit Toggle = ");
			display_binary_num (s_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}
  //      break;
#endif
#if 0
//    case 5:
        printf("Enter the positive number = ");
        scanf("%d", &s_num);
        printf("Enger the position = ");
        scanf("%d", &s);
        res = bit_ts(s_num, s);
        printf("Result of Test and Set bit = %x\n", res);
        break;
#endif
#if 0
	//case 6:
        printf("Enter the positive number = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str); 


        res = left_rotate_bits(&s_num);
		if (res == SUCCESS) {
			printf("Left Rotate Bits = ");
			display_binary_num (s_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}
#endif
#if 0
        printf("Enter the positive number = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str); 


        res = right_rotate_bits(&s_num);
		if (res == SUCCESS) {
			printf("Right Rotate Bits = ");
			display_binary_num (s_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}
       // break;
#endif
#if 0
    //case 7:
		printf("Enter the positive number = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str); 

        printf("Enter the no of bits = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}
		num = atoi(str);

        res = left_rotate_n_bits(&s_num, num);
		if (res == SUCCESS) {
			printf("Right Rotate Bits = ");
			display_binary_num (s_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}
#endif
#if 0
		printf("Enter the positive number = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str); 

        printf("Enter the no of bits = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}
		num = atoi(str);

        res = right_rotate_n_bits(&s_num, num);
		if (res == SUCCESS) {
			printf("Right Rotate Bits = ");
			display_binary_num (s_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}

       // break;
#endif
#if 0 
    //case 8:
        printf("Enter the positive number = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str); 
        res = count_trailing_clear_bits(&s_num, &count);
		if (res == SUCCESS) {
			printf("Set bit count = %d\n", count);
			//display_binary_num (s_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}
#endif
#if 0
		printf("Enter the positive number = ");
		if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str); 

        res = count_clear_bits(&s_num, &count);
		if (res == SUCCESS) {
			printf("Clear bit count = %d\n", count);
			//display_binary_num (s_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}

#endif
#if 0
    case 9:
        printf("Enter the positive number = ");
        scanf("%x", &s_num);
        
        res = cnt_leading_set_bits(s_num);
        printf("No of Leading set bits = %d\n", res);

        res = cnt_leading_cleared_bits(s_num);
        printf("No of Leading Clear bits = %d\n", res);
        
        res = cnt_trailing_set_bits(s_num);
        printf("No of Trailing set bits = %d\n", res);

        res = cnt_trailing_cleared_bits(s_num);
        printf("No of Trailing Clear bits = %d\n", res);
        break;
    case 10:
#endif
#if 0
        printf("Enter s_num = ");
       	if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str); 
        
		printf("Enter d_num = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		d_num = atoi(str); 

        printf("Enter pos = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_pos = atoi(str); 

        printf("Enter num = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		num = atoi(str); 
        
        res = setbits(&s_num, s_pos, num, &d_num);
		if (res == SUCCESS) {
			printf("Set bit = ");
			display_binary_num (s_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}
#endif
#if 1
        printf("Enter s_num = ");
       	if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_num = atoi(str); 
        
        printf("Enter pos = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		s_pos = atoi(str); 

        printf("Enter num = ");
        if (fgets (str, MAX, stdin) == NULL) {
			printf ("Enter choice as integer!\n");
			exit (0);
		}	
		num = atoi(str); 
        
        res = invert(&s_num, s_pos, num);
		if (res == SUCCESS) {
			printf("Invert bit = ");
			display_binary_num (s_num);
		}
		else {
			printf ("Integer or position validation failed!\n");
		}
#endif

#if 0
		break;

    case 11:
        printf("Enter x = ");
        scanf("%d", &s_num);
        printf("Enter p = ");
        scanf("%d", &s);  
        printf("Enter n = ");
        scanf("%d", &n);

        res = invert(s_num, s, n);
        printf("x after invertnig bits = %x\n", res);
        break;
    case 12:
        printf("Enter x = ");
        scanf("%d", &s_num);
        printf("Enter p = ");
        scanf("%d", &s);  
        printf("Enter n = ");
        scanf("%d", &n);

        res = getbits(s_num, s, n);
        printf("get bits = %x\n", res);
        break;
    case 13:
        printf("Enter x = ");
        scanf("%x", &s_num);

        res = clear_rightmost_set_bit(s_num);
        printf("Clear Rightmost Set bit = %x\n", res);

        res = set_rightmost_cleared_bit(s_num);
        printf("Set Rightmost Cleared bit = %x\n", res);
        
        d_num = s_num;
        clear_leftmost_set_bit(d_num);
        printf("Clear Leftmost Set bit = %x\n", d_num);

        d_num = s_num;
        set_leftmost_cleared_bit(d_num);
        printf("Set Leftmost Cleared bit = %x\n", d_num);
        break;
    case 14:
        printf("Enter x = ");
        scanf("%d", &s_num);
        printf("Enter s = ");
        scanf("%d", &s);  
        printf("Enter d = ");
        scanf("%d", &d);
        
        if (s < d) {
            printf("Set bit from %d to %d = %x\n", s, d, setbits_stod(s_num, s, d));
            printf("Clear bit from %d to %d = %x\n", s, d, clearbits_stod(s_num, s, d));
            printf("Toggle bit from %d to %d = %x\n", s, d, togglebits_stod(s_num, s, d));
        } else {
            printf("S should be smaller than d");
        }
        break;
    case 15:
        printf("Enter num 1 = ");
        scanf("%d", &s_num);
        printf("Enter num 2 = ");
        scanf("%d", &d_num);

        printf("Maximum = %d\n", maximum(s_num, d_num));
        printf("Minimum = %d\n", minimum(s_num, d_num));
        break;
    default:
        printf("Wrong choice!\n");
    }*/
#endif
   
    return 0;
}
       
     
