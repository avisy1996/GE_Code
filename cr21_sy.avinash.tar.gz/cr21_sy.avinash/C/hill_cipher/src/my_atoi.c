#include "hill_cipher.h"

int my_atoi(char *str)
{
    long res = 0;
	long sign = 1;
    
	if (*str == '+') {
        sign = 1;
        str ++;
    }
    if (*str == '-') {
        sign = -1;
        str ++;
		return -1;
	} 

    while (*str != '\n')
    {
        if(*str >= '0' && *str <= '9') {
            res = res * 10 + (*str - '0');
        }
        else {
            return -1;
        }
        str ++;
    }
    res = res * sign;
	
	if (res < 0 || res > INT_MAX) {
		return -1;
    } 
   // printf ("%d\n", res);
    return res;
}
