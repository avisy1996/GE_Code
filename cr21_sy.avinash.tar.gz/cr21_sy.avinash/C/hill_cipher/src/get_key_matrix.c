#include "hill_cipher.h"

int get_key_matrix(int row, int col, int key_matrix[][col]) 
{
	int i, j, num;
	char ch_num[MAX];
	printf ("%dx%d key matrix\n", row, col);
	for (i = 0; i < row; i ++) {
		for (j = 0; j < col; j ++) {
			printf ("key_matrix[%d][%d] : ", i, j);
			if (fgets (ch_num, MAX, stdin) == NULL) {
				perror("Enter numbers");
				return 0;
			}
			
			num = my_atoi (ch_num);
			if (num == -1) {
				perror ("Not a valid no");
				return 0;
			}
			//*((key_matrix + i * col) + j) = num;
			key_matrix [i][j] =num;
		}
	}
	for (i = 0; i < row; i ++) {
		for (j = 0; j < col; j ++) {
		    printf("%d ",key_matrix[i][j]);
        }
        printf("\n");
    }
	
	return 1;
}
