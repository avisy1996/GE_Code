#include "hill_cipher.h"

int main (int argc, char **argv)
{
	int key_matrix[MAX][MAX], matrix_mul[3][3];
	int row, col, p_len, succ, i, j, k, num;
	long determinant = 0;
	double inverse [3][3], inverse_t[3][3];
    int submsg[3][1];
	char plain_text[MAX], ch_i[MAX],
		 encrypt[3][1], decrypt[3][1];

	printf ("Enter Plain text of 3 letters : ");
    if (fgets (plain_text, MAX, stdin) == NULL) {
        perror ("Enter plain text!");
        exit (0);
    }
    
    p_len = strlen (plain_text);

   /* printf ("Enter no of characters from plain text you want to encrypt : ");
    if (fgets (ch_i, MAX, stdin) == NULL) {
        perror ("Enter chunks");
        exit (0);
    }*/

    /*succ = my_atoi (ch_i);
    if (succ == -1 || succ > p_len) {
        printf("Enter no of characters should be less than plain text length");
        exit (0);
    }*/
    succ = 3;
    row = succ; 
    col = succ;
    printf ("%dx%d key matrix\n", row, col);
	for (i = 0; i < row; i ++) {
		for (j = 0; j < col; j ++) {
			printf ("key_matrix[%d][%d] : ", i, j);
			if (fgets (ch_i, MAX, stdin) == NULL) {
				perror("Enter numbers");
				return 0;
			}
			
			num = my_atoi (ch_i);
			if (num == -1) {
				perror ("Not a valid no");
				return 0;
			}
			//*((key_matrix + i * col) + j) = num;
			key_matrix [i][j] = num;
		}
	}
    
	for (i = 0; i < row; i++) {
        for (j = 0; j < col; j++) {
            printf ("%d ", key_matrix[i][j]);
        }
        printf ("\n");
    }

	/**** Encryption ****/

	for (i = 0; i < 3; i ++) {
		submsg[i][0] = plain_text[i] - 65;
		//printf ("%d ", submsg[i][0]);
	}

	for(i=0; i<3; ++i)
		for(j=0; j<1; ++j)
			for(k=0; k<3; ++k){
				matrix_mul[i][j] += key_matrix[i][k] * submsg[k][j];
			}
    for (i = 0; i < 3; i++) { 
        for (j = 0; j < 1; j++) {
            printf ("%d ", matrix_mul[i][j]);
			encrypt [i][j] = matrix_mul[i][j] % 26;
        }
        printf ("\n");
	}
    
	for (i = 0; i < 3; i++) { 
        for (j = 0; j < 1; j++) {
			printf ("%d ", encrypt[i][j]);
            printf ("%c ", encrypt[i][j] + 65);
			//encrypt [i][j] = matix_mul[i][j] % 26;
        }
        printf ("\n");
	}


	/**** Decription ****/
//	for (i = 0; i < 3; i++) {
/*		determinant = determinant + (key_matrix[0][i]*(key_matrix[1][(i+1)%3] *
 *		key_matrix[2][(i+2)%3] - key_matrix[1][(i+2)%3] *
 *		key_matrix[2][(i+1)%3])); */
determinant = key_matrix[0][0]*((key_matrix[1][1]*key_matrix[2][2]) -
		(key_matrix[2][1]*key_matrix[1][2])) - key_matrix[0][1]*(key_matrix[1][0]*key_matrix[2][2] - key_matrix[2][0]*key_matrix[1][2]) + key_matrix[0][2]*(key_matrix[1][0]*key_matrix[2][1] - key_matrix[2][0]*key_matrix[1][1]);

	determinant = determinant % 26;
	printf ("Det = %ld\n", determinant);
   printf("\nInverse of matrix is: \n\n");
   for(i=0;i<3;i++){
      for(j=0;j<3;j++) {
			inverse[i][j] = ((key_matrix[(i+1)%3][(j+1)%3] *
						key_matrix[(i+2)%3][(j+2)%3]) -
					(key_matrix[(i+1)%3][(j+2)%3]*key_matrix[(i+2)%3][(j+1)%3]))
				 * (1 / (float)determinant);
			printf ("%lf ", inverse[i][j]);
		}
		printf ("\n");
			
	  }
   for (i=0;i<3;i++) {
	   for(j=0;j<3;j++) {
		   inverse_t[j][i] = inverse[i][j];
		//printf ("%.4f ", inverse_t[j][i]);
	   }
	   printf("\n");
   }
   for (i=0;i<3;i++) {
	   for(j=0;j<3;j++) {
		   //inverse_t[j][i] = inverse[i][j];
			printf ("%lf ", inverse_t[i][j]);
	   }
	   printf("\n");
   }

	for(i=0; i<3; ++i) {
		for(j=0; j<1; ++j) {
			for(k=0; k<3; ++k){
				matrix_mul[i][j] += inverse_t[i][k] * encrypt[k][j];
			}
		}
	}
    for (i = 0; i < 3; i++) { 
        for (j = 0; j < 1; j++) {
           // printf ("%d ", matrix_mul[i][j]);
			decrypt [i][j] = matrix_mul[i][j] % 26;
			printf ("%d ", decrypt[i][j]);
        }
        printf ("\n");
		//printf("%d\n", matrix_mul[i][0]);
	}
    
	for (i = 0; i < 3; i++) { 
        for (j = 0; j < 1; j++) {
            printf ("%c ", decrypt[i][j] + 65);
			//encrypt [i][j] = matix_mul[i][j] % 26;
        }
        printf ("\n");
	}

    return 0;
}

