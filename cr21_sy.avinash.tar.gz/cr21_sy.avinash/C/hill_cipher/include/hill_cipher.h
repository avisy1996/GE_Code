#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#define VALID 1
#define INVALID 0
#define MAX 100
#define MATRIX_SIZE 3

int my_atoi (char *str);
int get_key_matrix(int row, int col, int key_matrix[][col]);
