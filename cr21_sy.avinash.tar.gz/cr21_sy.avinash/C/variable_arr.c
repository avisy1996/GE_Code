#include <stdio.h>
#define MAX 20

void declare_array (int n)
{
	char cno[MAX];
	int arr[n];
	int i;
	for (i = 0; i < n; i ++) {
		if (fgets (cno, MAX, stdin) == NULL) {
			perror ("fgets error");
		}
		arr[i] = atoi(cno);
	}
	for (i = 0; i < n; i ++)
		printf("%d\n", arr[i]);
	return;
}

int main(void)
{
	char c_no[MAX];
	int n;
	printf ("Enter n : ");
	if (fgets (c_no, MAX, stdin) == NULL) {
		perror ("fgets error");
	}
	n = atoi (c_no);
	declare_array(n);
	return 0;
}
