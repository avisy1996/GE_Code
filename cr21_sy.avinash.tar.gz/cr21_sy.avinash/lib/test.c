#include <stdio.h>

int main (void) 
{
	char str1[] = "Avinash ";
	char str2[6] = "Yadav";
	str_cpy(str2, str1);
	printf ("%s\n", str2);

	return 0;
}
