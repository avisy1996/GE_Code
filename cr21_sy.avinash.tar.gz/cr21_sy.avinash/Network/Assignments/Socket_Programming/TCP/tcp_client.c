#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define ERROR -1
#define ZERO 0
#define MAX 100
#define PORT 5555

int main(void)
{
	int sockfd;
	struct sockaddr_in serv_addr;
	socklen_t fromlen;
	char serv_buf[MAX];
	char client_buf[MAX];

	memset (&serv_addr, ZERO, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons (PORT);

	sockfd = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (ERROR == sockfd) {
		printf ("sockfd not created\n");
	}

	if (ERROR == (connect (sockfd, (struct sockaddr *)&serv_addr,
					sizeof(serv_addr)))) {
		perror ("Connect");
	}

	while (strcmp(client_buf, "bye\n") != ZERO) {
		printf ("Client : ");
		fgets (client_buf, MAX, stdin);
		if(ERROR == write (sockfd, client_buf, sizeof(client_buf))) {
			perror("Write\n");
		}

		if (ERROR == read (sockfd, serv_buf, MAX)) {
			perror ("Read");
		}
		printf ("Server : %s", serv_buf);
	}

	close(sockfd);
	return 0;
}
