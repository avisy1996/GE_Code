#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/syscall.h>

#define ERROR -1
#define ZERO 0
#define MAX 100
#define MAX_REQ 10
#define PORT 5555

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void *socketThread(void *arg) 
{
	int newsockfd = *((int *) arg);
	char serv_buf[MAX], client_buf[MAX];

	while (strcmp(serv_buf, "bye\n") != ZERO) {
		if (ERROR == read (newsockfd, client_buf, MAX)) {
			perror ("Read");
		}
		
		if (ZERO != pthread_mutex_lock(&lock)) {
			perror ("pthread mutex lock");
		}
		
		printf ("Client %d: %s", syscall(SYS_gettid), client_buf);

		printf ("Server %d: ",syscall(SYS_gettid));
		if (NULL == fgets (serv_buf, MAX, stdin)) {
			perror ("fgets");
		}
		
		if (ZERO != pthread_mutex_unlock (&lock)) {
			perror ("pthread mutex unlock");
		}
		
		sleep (1);

		if(ERROR == write (newsockfd, serv_buf, sizeof(serv_buf))) {
			printf("Write\n");
		}
	}

	pthread_exit (NULL);
}
int main(void)
{
	int sockfd, newsockfd;
	struct sockaddr_in client_addr, serv_addr;
	socklen_t client_len;
	int i = ZERO, j = ZERO;
	pthread_t tid[MAX_REQ];

	memset (&serv_addr, ZERO, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons (PORT);

	client_len = sizeof(client_addr);
	sockfd = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (ERROR == sockfd) {
		perror ("sockfd not created\n");
	}

	if(ERROR == bind (sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr))) {
		perror ("bind failed");
	}

	if (ERROR == listen (sockfd, MAX_REQ)) {
		perror ("listen");
	}

	while (1) {
		if ((newsockfd = accept (sockfd, (struct sockaddr *) &client_addr, &client_len))
				<= ZERO) {
			printf ("New socket not created\n");
		}

		if (ZERO != pthread_create (&tid[i ++], NULL, socketThread, &newsockfd)) {
			printf ("Pthread create failed\n");
		}

	}
	while (j < i) {
		pthread_join (tid[j ++], NULL);
	}
	close(sockfd);

	return ZERO;
}
