#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define ZERO 0
#define MAX 100
int main(void)
{
	int sockfd;
	struct sockaddr_in ca, sa;
	socklen_t fromlen;
	char buf[MAX];
	char buf1[MAX];

	memset (&ca, ZERO, sizeof(ca));
	memset (&sa, ZERO, sizeof(sa));
	sa.sin_family = AF_INET;
	sa.sin_addr.s_addr = inet_addr("127.0.0.1");// INADDR_ANY;
	sa.sin_port = htons (6620);

	sockfd = socket (PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (-1 == sockfd) {
		printf ("sockfd not created\n");
	}

	if(bind (sockfd, (struct sockaddr *)&sa, sizeof(sa)) == -1) {
		perror ("bind");
	}

	while (strcmp(buf, "\n") != 0) {
		recvfrom (sockfd, buf, MAX, 0, (struct sockaddr*) &ca, &fromlen);
		printf ("Client : %s", buf);

		printf ("Server : ");
		fgets (buf1, MAX, stdin);

		if(0 >= sendto (sockfd, buf1, sizeof(buf1), 0, (const struct sockaddr*)
					&ca, sizeof(ca))) {
			printf("not sent\n");
		}
	}

	close(sockfd);
	return 0;
}
