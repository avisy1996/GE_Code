#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#define ZERO 0
#define MAX 100
int main(void)
{
	int sockfd;
	struct sockaddr_in sa;
	socklen_t fromlen;
	char buf[MAX];
	char buf1 [MAX];

	sockfd = socket (PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (-1 == sockfd) {
		printf ("sockfd not created\n");
	}

	memset (&sa, ZERO, sizeof(sa));
	sa.sin_family = AF_INET;
	sa.sin_addr.s_addr = /*INADDR_ANY;*/inet_addr("127.0.0.1");
	sa.sin_port = htons (6620);

	while (strcmp (buf, "\n") != ZERO) {	
		printf ("Client : ");
		fgets (buf, MAX, stdin);
		sendto (sockfd, buf, sizeof(buf), 0, (struct sockaddr*) &sa,
			sizeof(sa));
	
		recvfrom (sockfd, buf1, MAX, 0, (struct sockaddr*) &sa, &fromlen);
		printf ("Server : %s", buf1);
	}

	close (sockfd);
	return 0;
}
