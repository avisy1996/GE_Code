#include <stdio.h>
#include <stdlib.h>
#define MAX 100
#define EMPTY -1
#define TRUE 1
#define FALSE 0
#define RED 1
#define BLACK 0

struct RBNode {
	struct RBNode *left;
	int data;
	int color:2;
	struct RBNode *right;
};

typedef struct RBNode tree;

int my_atoi(char *);

tree *search_node (tree *, tree **, tree **, int);
tree *create_node (int);
tree *BST_insert_node (tree *, tree *);
tree *BST_delete_node (tree *, int);
tree *fix_insert_violations (tree *, tree *);
tree *fix_delete_violations (tree *, tree *);

tree *rotate_left (tree *);
tree *rotate_right (tree *);
tree *inorder_successor (tree *);
void inorder (tree *);
void preorder (tree *);
void postorder (tree *);
