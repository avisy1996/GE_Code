#include<stdio.h>
#include<stdlib.h>

#define MAX 50

typedef struct s_list
{
	int data;
	struct s_list *next;
}sll;

void display_list(sll *);
int menu();
sll *getlast_node();	
sll *create_node();
int node_count(sll *);
sll* return_pos_node(sll * , int pos); 
int my_atoi(char*);

/*Insert Function*/
sll* insert_begin(sll *);  
sll* insert_end(sll *);
sll* insert_n_pos(sll *, int pos);
sll* insert_before_n_pos(sll *, int pos);
sll* insert_after_n_pos(sll *, int pos);
sll* insert_before_num_pos(sll *, int num);
sll* insert_after_num_pos(sll *, int num);
sll* insert_middle(sll *);
sll* penultimate_node(sll *); 

/*Delete Function*/
sll *delete_begin(sll *);
sll *delete_end(sll *);
sll *delete_n_pos(sll *, int);
sll *delete_before_n_pos(sll *, int);
sll *delete_after_n_pos(sll *, int);
sll *delete_before_num_pos(sll *, int);
sll *delete_after_num_pos(sll *, int);
sll *delete_at_middle(sll *);
sll *delete_penultimate_node(sll *);
