#include <stdio.h>
#include <stdlib.h>
#define MAX 100
#define EMPTY -1
#define TRUE 1
#define FALSE 0
struct Node {
	struct Node *left;
	int data;
	struct Node *right;
};
struct Queue {
	int data[MAX];
	int front;
	int rear;
};
typedef struct Queue queue;
typedef struct Node node;

int my_atoi(char *);

node *create_node (int, int *);
node *insert_node (node *, int, int *);
node *delete_node (node *, int, int *);
node *inorder_successor (node *);
void inorder (node *);
void preorder (node *);
void postorder (node *);

int enqueue (queue *, int);
int dequeue (queue *, int);


