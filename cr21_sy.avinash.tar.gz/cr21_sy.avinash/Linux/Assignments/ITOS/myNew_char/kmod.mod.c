#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x347f03c2, "module_layout" },
	{ 0x303aa3ae, "param_ops_charp" },
	{ 0xbbfa6e82, "device_destroy" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x37a0cba, "kfree" },
	{ 0xd4111fdf, "cdev_del" },
	{ 0x1ea5dda1, "class_destroy" },
	{ 0x87361776, "device_create" },
	{ 0xd2e16629, "__class_create" },
	{ 0x944bd3b7, "cdev_add" },
	{ 0x2e9212cf, "cdev_init" },
	{ 0x95b8ad3, "cdev_alloc" },
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0x50eedeb8, "printk" },
	{ 0xbdfb6dbb, "__fentry__" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "F556A83BD03E5308E59D1AF");
