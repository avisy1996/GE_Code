#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#include <semaphore.h>

#define MAX 10
#define LENGTH 4096

int main (void)
{
	int shm;
	int buf [MAX] = {};
	void *map;	
	int i;
	sem_t *my_sem;

	for (i = 1; i <= 10; i ++) {
		buf[i] = time(NULL) % i;
	}

	shm = shm_open ("/my_shm", O_CREAT | O_TRUNC | O_RDWR, 777);
	if (shm == -1) {
		perror ("shm open : ");
	}

	if (ftruncate (shm, LENGTH) == -1) {
		perror ("Truncate : ");
	}

	map = mmap (NULL, LENGTH, PROT_READ | PROT_WRITE, MAP_SHARED, shm, 0);
	if(map == MAP_FAILED) {
		perror ("mmap : ");
	}

	buf[0] = 1;
	if (write (shm, &buf[0], sizeof(int) * MAX) == -1) {
		perror ("Write : ");
		return -1;
	}

	while (buf[0] != 1);

	if (write (shm, buf, sizeof(int) * MAX) == -1) {
		perror ("Write : ");
		return -1;
	}
	
	printf ("Write %d\n", buf [0]);	
	
	buf[0] = 0;
	if (write (shm, &buf[0], sizeof(int) * MAX) == -1) {
		perror ("Write : ");
		return -1;
	}
	
	while (buf[0] != 1){
		if (read (shm, &buf[0], sizeof(int) * MAX) == -1) {
			perror ("Read : ");
		}
	}

	if (read (shm, buf, sizeof(int) * MAX) == -1) {
		perror ("Read : ");
	}

	for (i = 1; i < 10; i ++) { 
		printf ("%d ", buf[i]);
	}

	munmap (map, LENGTH);	
	shm_unlink ("/my_shm");
	return 0;
}
