#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
int main ()
{
    int pipefd[2];
    pid_t cpid;
    char buf;
    int newfd;

    if (pipe (pipefd) == -1) {
        perror ("pipe");
        exit (EXIT_FAILURE);
    }

    cpid = fork ();
    if (cpid == -1) {
        perror ("fork");
        exit (EXIT_FAILURE);
    }

    if (cpid != 0) {
        close (STDOUT_FILENO);
        dup (pipefd [1]);

        if (execlp ("ls", "ls", NULL) == -1)
            printf ("Failed ls execv\n");
    } else {
        close (STDIN_FILENO);        
        close (pipefd[1]);
        dup (pipefd[0]);
        
        execlp ("wc", "wc", NULL);
    }
    return 0;
}
