#include <mqueue.h>        
#include <signal.h>     
#include <string.h>
#include <stdlib.h>
#include <stdio.h>     
#include <errno.h>   
#include <fcntl.h>    
#include <sys/stat.h>
#include <sys/types.h>
#define name "/new_queue"
#define MSG_SIZE       8192     
#define MQ_PRIO_MAX    10  
#define MAX_MSG        10

int main(int argc, char *argv[])
{
	struct mq_attr attr;
	attr.mq_maxmsg = 100;
	attr.mq_msgsize = MSG_SIZE;
	attr.mq_curmsgs = 10;  
	attr.mq_flags = 0; 
	mqd_t mqd;
	ssize_t nr;
	char buf[MSG_SIZE];
	char buf1[MSG_SIZE];

	printf(">>>>>>>Message Queue<<<<<<<\n");

	mqd = mq_open(name , O_CREAT | O_RDWR, 666 , &attr );
	while(1) {
	    if (-1 != mqd) {
		    if (!mq_getattr(mqd, &attr)) {
                    printf("Message:\n");
		    	    nr = mq_receive(mqd, buf, 8192, NULL);
		        	perror("mq_receive()");
    			    if (nr >= 0) {
	    			    printf("Message is coming frm TOM :%s \n", buf);
		        	}
                    printf("Give the reply to TOM\n");
                    fgets(buf1, MSG_SIZE, stdin);
                    mq_send(mqd, buf1, strlen(buf1), 0);
	        	} else {
		         	perror("mq_getattr()");
		     }
	      } else {
		           perror("mq_open()");
          }
    }
            mq_close(mqd);
	        mq_unlink(name);
}
