#include <mqueue.h>        
#include <string.h>
#include <signal.h>     
#include <stdlib.h>
#include <stdio.h>     
#include <errno.h>   
#include <fcntl.h>    
#include <sys/stat.h>
#include <sys/types.h>
#define name "/new_queue"
#define MSG_SIZE       8192     
#define MQ_PRIO_MAX    10  
#define MAX_MSG        5

int main(int argc, char *argv[])
{
	struct mq_attr attr;
	attr.mq_maxmsg = 5;
	attr.mq_msgsize = MSG_SIZE;
	attr.mq_curmsgs = 0;  
	attr.mq_flags = 0; 
	mqd_t mqd;
	ssize_t nr;
	char buf[MSG_SIZE + 1];
	char buf1[MSG_SIZE];

	printf(">>>>>>>Message Queue<<<<<<<\n");
	mqd = mq_open(name , O_CREAT | O_RDWR , 666, &attr);
	while(1) {
		if (-1 != mqd) {
			if (!mq_getattr(mqd, &attr)) {
				printf("Enter the message:\n");
				fgets(buf, 300, stdin);
				if((mq_send(mqd, buf, strlen(buf), 0)) != -1) {
					if(nr = mq_receive(mqd, buf1, MSG_SIZE, NULL) != -1) {
						printf("The received reply from Jerry:\n");
						printf("%s \n", buf1);
					} else {
						perror("mq_receive");
					}
				} else {
					perror("mq_send");
				}
			} else {
				perror("mq_getattr()");
			}
		}
	}	

	mq_close(mqd);
}
