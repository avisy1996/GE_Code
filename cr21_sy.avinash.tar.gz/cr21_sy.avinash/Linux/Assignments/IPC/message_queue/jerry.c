#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>

#define MAX 8192

int main (void)
{
	mqd_t mqd;
	char buf [MAX];
		
	mqd = mq_open ("/my_mqueue", O_CREAT | O_RDWR, 777, NULL);
	if (mqd == -1)
		perror ("failed to create mqueue : ");

	do {
		if (mq_receive (mqd, buf, 8192, 0) == -1)
			perror ("Receive : ");
		
		printf ("Tom : %s", buf);
		
		printf ("Jerry : ");
		fgets (buf, MAX, stdin);
		if (mq_send (mqd, buf, sizeof(buf), 0) == -1)
			perror ("Send : ");
	} while (*buf != '\n');

	mq_close (mqd);
}
