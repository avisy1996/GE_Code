#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define MAX 100
int main (void)
{
	int fd;
	char buf [MAX];

	if (mkfifo ("mypipe", 777) != 0) {
		perror ("Error in mkfifo\n");
	}
	printf ("Pipe is created!\n");
	
	fd = open ("mypipe", O_CREAT | O_WRONLY, 777);

	if (fd == -1) {
		perror ("file not created\n");
	}

	do {
		printf ("Enter message : ");
		fgets (buf, MAX, stdin);

		if (write (fd, buf, sizeof(buf)) != -1) {
		}
	} while (*buf != '\n');
	write (fd, '\0', sizeof(char));
	close (fd);	
	return 0;
}
