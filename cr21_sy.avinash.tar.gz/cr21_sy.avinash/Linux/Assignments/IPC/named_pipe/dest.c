#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define MAX 100

int main (void)
{
	int fd;
	char buf [MAX];
	
	fd = open ("mypipe", O_RDONLY, 777);

	if (fd == -1) {
		perror ("file not created\n");
	}

	do {
		if (read (fd, buf, MAX) != -1) {
			printf ("%s", buf);
		}
	} while (*buf != '\n');
	close (fd);
		
	return 0;
}
