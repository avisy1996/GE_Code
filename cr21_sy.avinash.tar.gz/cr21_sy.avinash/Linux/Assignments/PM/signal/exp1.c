#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

void catch_ctlc(int sig_num)
{
	printf ("Caught Ctrl-C\n");
	fflush (stdout);
	return;
}

int main()
{
	signal (SIGINT, catch_ctlc);
	printf ("Go ahead\n");
	pause();
	return 0;
}

