#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int g_ivar = 10;
int main()
{
	int l_ivar = 20;
	pid_t cpid = vfork();
	
	if (cpid > 0) {
		getchar();
		printf ("Parent PID : %d\n", getpid());
		printf ("&g_ivar = 0x%08x\n", (unsigned int)&g_ivar);
		printf ("&l_ivar = 0x%08x\n", (unsigned int)&l_ivar);
	}
	else if (cpid == 0) {
		g_ivar = 20;
		l_ivar = 30;
		printf ("Child PID : %d\n", getpid());
		printf ("&g_ivar = 0x%08x\n", (unsigned int)&g_ivar);
		printf ("&l_ivar = 0x%08x\n", (unsigned int)&l_ivar);
		exit (0);
	}
	else {
		printf ("fork() failed\n");
	}
	return 0;
}
