#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <time.h>
//#include "errors.h"

typedef struct Alarm{
	clock_t time;
	char message [64];
	struct Alarm *next;
} alarm;

typedef struct my_strct_tag {
	pthread_mutex_t	mutex;
	alarm *head;
	pthread_cond_t cond;
} my_struct_t;

my_struct_t *data;
/*
void *insert_alarm (void *p) 
{
	alarm *al;
	int sec;
	char str[100];
	clock_t cur_time;
	int status;

	printf ("Enter alarm time : ");
	//if (fgets (str, 100, stdin) == NULL) exit (0);
	//sec = atoi (str);
	scanf ("%d", &sec);

	al = (alarm *) malloc (sizeof (alarm));
	if (al == NULL) {
		perror ("Malloc failed\n");
		exit (0);
	}

	cur_time = time (NULL);
	al -> time = cur_time + sec;
	al -> next = NULL;
	
	/* Linked list node insertion 
	status = pthread_mutex_lock (&data -> mutex);	
	if (status != 0)
		perror ("Error lock\n");
	if (data -> head == NULL) {
		data -> head = al;
	}
	else {
		alarm *cur, *prev;
		cur = data -> head;
		prev = cur;

		while (cur -> time < al -> time || cur -> next != NULL) {
			prev = cur;
			cur = cur -> next;
		}

		if (cur -> time > al -> time && prev -> time < al -> time) {
			al -> next = cur;
			prev -> next = al;
		}
		else if (cur -> next == NULL) {
			cur -> next = al;
		}
	}
	pthread_mutex_unlock (&data -> mutex);
	if (status != 0)
		perror ("Error unlock\n");
	
	return;
}*/


void *delete_alarm (void *p)
{
	int status;
	int sec;
	clock_t cur;
	alarm *al;

	//printf ("In thread delete\n");
	while (1)
	{
		//while (data -> head == NULL) 
		//	sleep (1);
		while (!data -> head == NULL) {
			status = pthread_cond_wait (&data -> cond, &data -> mutex);
			if (status != 0)
				printf ("Cond Wait %s\n", (char*)strerror (status));
		}
		printf("After cond\n");
		al = data -> head;
		data -> head = al -> next;
		
		pthread_mutex_unlock (&data -> mutex);
		if (status != 0)
			perror ("Error unlock\n");

		cur = time (NULL);
		sec = al -> time - cur;
		sleep (sec);
		printf ("Alarm > %d", sec);
		
		free (al);	
	}
	return;
}



int main (void)
{
	int status, i = 0;
	pthread_t th_id1, th_id2;
	alarm *al;
	int sec;
	char str[100];
	clock_t cur_time;
	
	data = malloc (sizeof (my_struct_t));
	if (data == NULL)
		perror ("Allocation structure\n");

	status = pthread_mutex_init (&data -> mutex, NULL);
	if (status != 0)
		perror ("Init mutex");
	status = pthread_cond_init (&data -> cond, NULL);
	if (status != 0)
		perror ("Init Condition");


	status = pthread_create (&th_id2, NULL, delete_alarm, NULL);
	if (status != 0)
		printf ("Delete Thread not created %s\n", (char*)strerror (status));

	while (1) {
		status = pthread_mutex_lock (&data -> mutex);	
		if (status != 0)
			perror ("Error lock\n");

		printf ("Alarm > ");
		if (fgets (str, 100, stdin) == NULL) exit (0);
		sec = atoi (str);

		al = (alarm *) malloc (sizeof (alarm));
		if (al == NULL) {
			perror ("Malloc failed\n");
			exit (0);
		}

		cur_time = time (NULL);
		al -> time = cur_time + sec;
		al -> next = NULL;
		
		/* Linked list node insertion */

		if (data -> head == NULL) {
			data -> head = al;
		}
		else {
			alarm *cur, *prev;
			cur = data -> head;
			prev = cur;

			while (cur -> time < al -> time && cur -> next != NULL) {
				prev = cur;
				cur = cur -> next;
			}
			if (cur == data -> head) {
				al -> next = cur;
				data -> head = al;
			}
			else if (cur -> time > al -> time) {
				al -> next = cur;
				prev -> next = al;
			}
			else if (cur -> next == NULL) {
				cur -> next = al;
			}
		}
		/*alarm *cur = data -> head;
		while (cur != NULL) {
			printf ("%d\n", cur -> time);
			cur = cur -> next;	
		}*/
		status = pthread_cond_signal (&data -> cond);
		if (status != 0)
			perror ("Error unlock\n");

		status = pthread_mutex_unlock (&data -> mutex);
		if (status != 0)
			perror ("Error unlock\n");
		
	}
	
	
	status = pthread_mutex_destroy (&data -> mutex);
	if (status != 0)
		perror ("Destroy mutex");

	(void)free (data);
	
	return status;
}

