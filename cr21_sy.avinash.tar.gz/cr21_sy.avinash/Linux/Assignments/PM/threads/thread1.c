#include <stdio.h>
#include <pthread.h>
#include <sys/syscall.h>
void *thread_function (void *p)
{
	printf ("I am in thread function\n");
	printf ("Thread PID : %d\n", syscall(SYS_gettid));
	printf ("Thread TID : %d\n", getpid());
	
	return NULL;
}

int main(void)
{
	int status;
	pthread_t th_id;
	
	status = pthread_create (&th_id, NULL, thread_function, NULL);
	
	if (status != 0) {
		printf ("Thread creation failed: %d", strerror(status));
	}

	printf ("Main Thread PID : %d\n", syscall(SYS_gettid));
	printf ("Main Thread TID : %d\n", getpid());
	pthread_exit (NULL);
	return 0;
}
