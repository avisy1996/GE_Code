#include <stdio.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <fcntl.h>
int fd;
void *thread_function (void *p)
{
	write (fd, "Software Ltd.\n", 14);
	printf ("I am in thread function\n");
	printf ("Thread PID : %d\n", syscall(SYS_gettid));
	printf ("Thread TID : %d\n", getpid());
	//printf ("%d\n", a);

	return NULL;
}

int main(void)
{
	int status;
	pthread_t th_id;
	int a = 10;
	fd = open ("just.txt", O_RDWR | O_CREAT);
	if (fd <= 0) {
		perror ("File not opened\n");
		return 0;
	}
	status = pthread_create (&th_id, NULL, thread_function, NULL);	

	if (status != 0) {
		printf ("Thread creation failed: %d", strerror(status));
	}

	write (fd, "Global Edge ", 11);
	printf ("Main Thread PID : %d\n", syscall(SYS_gettid));
	printf ("Main Thread TID : %d\n", getpid());
	//getchar ();
	close (fd);
	pthread_exit (NULL);
	return 0;
}
