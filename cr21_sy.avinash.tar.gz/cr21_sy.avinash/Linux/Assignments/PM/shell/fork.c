#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>

#define MAX 256

int main(void)
{
	char ip[MAX];
	pid_t pid;

	printf("-------START OF SHELL PROGRAM-------\n\n");
	

	while(1)
	{
		printf("|$|");

		int i = 0, len = 0;
		char *args[MAX];  
		char *c;
		const char *delim = " ";
		
		char *env1[] = {NULL};
		if(!fgets(ip,MAX,stdin)) 
			break;

		char *p = strchr(ip,'\n'); 
		
		if(p) {
			*p=0;			 
		}

		if(!strcmp(ip,"exit")) {
			break;
		}

		c = strtok(ip,delim);   

		while(c) {	
			args[i] = c; 
			c = strtok(NULL,delim);   
			++i;
		}

		args[i] = NULL;
		pid = fork();
		
		if(pid == 0) { 
			execvpe(args[0],args,env1); 
		} 
		else {
			wait(NULL);
		}
	}
	return 0;
}

