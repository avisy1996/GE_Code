#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>

int main(void)
{
	int fd;
	fd = open ("/dev/myChar", O_RDWR);
	int i = 10;
	printf ("%d\n", (int)getpid());
	//long l = (*unlocked ioctl) (
	
	if (fd < 0) {
		perror ("Unable to open the device");
	}
	else{ 
		pid_t pid = fork();
		if (pid > 0)
		{
			int res = ioctl (fd, 1, getpid());
		}
		/*else if(pid == 0)
		{
			i = 20;
			int res = ioctl (fd, 1, getpid());
		}
		else 
		{
			printf ("Failure\n");
		}*/
		printf ("Device opened Successfully %d\n", fd);
//		int res = ioctl (fd, 1, getpid());
	}
	getchar();
	close (fd);

	return 0;
}
