//#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/cdev.h>
//#include <asm/uaccess.h>
//#include <linux/device.h>
#include <linux/slab.h>
#include <linux/ioctl.h>
#include <linux/mm.h>
#include <linux/fdtable.h>

MODULE_LICENSE ("Dual BSD/GPL");

/** Constatnts **/
#define FIRST_MINOR	10
#define NR_DEVS 1	//Number of device numbers

//Function Declarations fo syscall definitions
int myOpen (struct inode *inode, struct file *filep);
int myRelease (struct inode *in, struct file *fp);
long myIoctl (struct file *filep, unsigned int cmd, unsigned long arg);
void my_f_path (struct dentry *);
//Initialization routines
static int myInit (void);
static void myExit (void);
struct file_operations fops = {
	.owner = THIS_MODULE,
	.open = myOpen,
	.release = myRelease,
	.unlocked_ioctl = myIoctl
};

/*Global variables*/
char *devname;	//constains device name
int majNo;
static dev_t mydev;	//encodes major number and minor number
struct cdev *my_cdev;	//hosds character device driver descriptor

/* to accept input from the comman line */
module_param(devname, charp, 0000);

//class and device stuctures
static struct class *mychar_class;
static struct device *mychar_device;

void my_f_path (struct dentry *den)
{
	struct qstr str = den -> d_name;

	//if(strcmp (den -> d_iname, "/") == 0 || strcmp (den -> d_iname, "home")) {
/*	if(strcmp(den->d_iname,"/")!=0) {
		my_f_path(den->d_parent);
		 
		printk(KERN_CONT "/%s", den -> d_iname);
//		return;
	}
	if (strcmp (den->d_iname, "/home") == 0) {
		my_f_path(den->d_parent);
		printk(KERN_CONT "/%s", den -> d_iname);
	}*/
	if(strcmp(str.name,"/")!=0) {
		my_f_path(den->d_parent);
		 
		printk(KERN_CONT "/%s", str.name);
		//		return;
	}
	if (strcmp (str.name, "/home") == 0) {
		my_f_path(den->d_parent);
		printk(KERN_CONT "/%s", str.name);
	}

	return;


//	f_path (den -> d_parent);
	//str = den -> d_name;
//	printk(KERN_CONT "/%s", den -> d_iname);
}
long myIoctl (struct file *filep, unsigned int cmd, unsigned long arg)
{
	struct task_struct *ts = current;
	struct mm_struct *m = ts -> mm;
	struct vm_area_struct *vmas = m -> mmap;


	int i = 1;

	printk(KERN_INFO "PID = %ld\n", (long int)ts -> pid);
//	printk(KERN_INFO "PPID = %ld\n", (long int)ts -> ppid);
//	printk(KERN_INFO "State = %ld\n", (long int)ts -> state);
//	
//	printk(KERN_INFO "%s\n", ts -> comm);
	
	while (vmas != NULL) {
		struct file * vmfile = vmas -> vm_file;
		
	/*	struct files_struct *fs = ts -> files;
		struct fdtable *fd_t = fs -> fdt;
		struct file **f_d = fd_t -> fd;
		struct path p = f_d[3] -> f_path;
		struct dentry *den = p.dentry;
		struct inode *in = den -> d_inode;*/

		printk ("%d\t 0x%08x-0x%08x ", i, (unsigned int) vmas -> vm_start, (unsigned int) vmas -> vm_end);

		if ((vmas -> vm_flags & VM_READ) == VM_READ) {
			printk(KERN_CONT "r");
		} else {
			printk(KERN_CONT "-");
		}
		if ((vmas -> vm_flags & VM_WRITE) == VM_WRITE) {
			printk(KERN_CONT "w");
		} else {
			printk(KERN_CONT "-");
		}
		if ((vmas -> vm_flags & VM_EXEC) == VM_EXEC) {
			printk(KERN_CONT "x");
		} else {
			printk(KERN_CONT "-");
		}
		if ((vmas -> vm_flags & VM_SHARED) == VM_SHARED) {
			printk(KERN_CONT "s");
		} else {
			printk(KERN_CONT "p");
		}

		printk(KERN_CONT " %08x ", (unsigned int) vmas -> vm_pgoff);

		//struct path f_pt = vm_file -> f_path
		if(vmfile != NULL) {

			struct path p = vmfile -> f_path;
			struct dentry *den = p.mnt -> mnt_root;

			struct inode *in = den -> d_inode;
			struct qstr str = den -> d_name;
				
			printk(KERN_CONT "%d:%d %d\t", MAJOR (in -> i_rdev) , MINOR(in-> i_rdev), in -> i_ino);
			printk(KERN_CONT "%s", str.name);
			//printk(KERN_CONT "/%s", den -> d_parent -> d_name.name);
			path_put (&p);
//			my_f_path (p->);
		}
		else {
			printk(KERN_CONT "00:00 0\t");
		}

		vmas = vmas -> vm_next;
		i ++;
	}
	
	return 0;
}

/*
 * myOpen: open function of the pseudo driver
 */
int myOpen (struct inode *inode, struct file *filep)
{
	printk(KERN_INFO "Open sucessful\n");
	return 0;
}

/*
 * myRelease: close function of the pseudo driver
 */


int myRelease (struct inode *in, struct file *fp)
{
	printk(KERN_INFO "File released\n");
	return 0;
}

/*
 * myInit: Init function of the kernel module
 */

static int __init myInit (void)
{
	int ret = -ENODEV;
	int status;

	printk (KERN_INFO "Initializing Character Device\n");

	//Allocating Device Numbers
	status = alloc_chrdev_region (&mydev, FIRST_MINOR, NR_DEVS, devname);
	if (status < 0)
	{
		printk (KERN_NOTICE "Device numbers allocation failed: %d\n", status);
		goto err;
	}

	printk (KERN_INFO "Major nubmer allocated = %d \n", MAJOR(mydev));
	my_cdev = cdev_alloc (); //Allocate memory for my_cdev
	if (my_cdev == NULL) {
		printk (KERN_ERR "cdev_alloc failed\n");
		goto err_cdev_alloc;
	}
	
	cdev_init (my_cdev, &fops);		//Initialize my_cdev with fops
	my_cdev -> owner = THIS_MODULE;

	status = cdev_add (my_cdev, mydev, NR_DEVS); //Add my_cdev to the list
	if (status) {
		printk (KERN_ERR "cdev_add failed\n");
		goto err_cdev_add;
	}

	//Create a class and n entry in sysfs
	mychar_class = class_create (THIS_MODULE, devname);
	if (IS_ERR (mychar_class)) {
		printk (KERN_ERR "class_create() failed\n");
		goto err_class_create;
	}
	
	//creates mychar_device in sysfs and an device entry will be made in /dev
	//directory
	mychar_device = device_create (mychar_class, NULL, mydev, NULL, devname);
	if (IS_ERR (mychar_device)) {
		printk (KERN_ERR "device_create() failed\n");
		goto err_device_create;
	}
	return 0;

err_device_create:
	class_destroy (mychar_class);

err_class_create:
	cdev_del(my_cdev);

err_cdev_add:
	kfree (my_cdev);

err_cdev_alloc:
	unregister_chrdev_region (mydev, NR_DEVS);

err:
	return ret;
}

/*
 * myExit: cleanup function of the kernel module
 */

static void __exit  myExit (void)
{
	printk (KERN_INFO "Exiting the Character Driver \n");
	device_destroy (mychar_class, mydev);
	class_destroy (mychar_class);
	cdev_del (my_cdev);
	unregister_chrdev_region (mydev, NR_DEVS);

	return;
}

module_init (myInit);
module_exit (myExit);
