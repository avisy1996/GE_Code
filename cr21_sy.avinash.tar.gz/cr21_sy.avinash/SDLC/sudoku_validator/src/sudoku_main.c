
#include "sudoku.h"

int main (int argc, char **argv)
{
//	FILE *fp =  NULL;
	int i, j;//, no, t_id;
	//int valid[NO_OF_THREADS], id, flag = 1;
	//pthread_t tid[NO_OF_THREADS];			//Create array of 27 pthread_t
	int arr[MAX][MAX];
	//char *line, *ch_num;
	//struct arg *arg_row [MAX], *arg_col[MAX], *arg_matrix[MAX];
	
	/*Check executable and sudoku solution file is provided or not*/
	if (argc != 2) {
		printf ("File name is required (./<executable> <filename>)\n");
		exit (0);
	}

#if 0
	fp = fopen (argv[1], "r");		//Open the file in read mode
	if (fp <= 0) {
		perror ("Unable to open file\n");
		exit (0);
	}

	line = (char *) malloc (MAX_SIZE);
	ch_num = (char *) malloc (MAX_SIZE);
	
	i = 0;

	/*Copy the Sulution from into 9x9 matrix*/
	while (fgets (line, MAX_SIZE, fp) != NULL) {
		ch_num = strtok (line, " \n\t");
		j = 0;
		while (ch_num != NULL) {
			no = my_atoi (ch_num);
			if (no == -1) {
				printf ("Invalid input at row = %d col = %d\n", i + 1, j + 1);
				exit (0);
			}
			arr [i][j] = no;
			ch_num = strtok (NULL, " \n\t");
			j ++;
		}
		/*Error if row in file has more than 9 entries*/
		if (j > MAX || j < MAX) {
			printf ("Sudoku Solution not complete!\n");
			exit (0);
		}
			
		i ++;
	}

	/*Error if no of columns in file has more than 9 entries or less than 9
	 * entries*/
	if (i < MAX || i > MAX || j < MAX) {
		printf ("Sudoku Solution not complete!\n");
		exit (0);
	}
#endif
	printf ("Before get input");
	if (get_input (argv[1], arr) == INVALID) {
		printf ("Sudoku solution is invalid\n");
		return 0;
	}
	/*Display the solution read from file*/
	printf ("\n***** Your Solution *****\n\n");
	for (i = 0; i < MAX; i ++) {
		for (j = 0; j < MAX; j ++) {
			printf ("%d ", arr [i][j]);
		}
		printf ("\n");
	}

	if (validate_sudoku (arr) == INVALID) {
		printf ("Invalid\n");
		return 0;
	}
#if 0
	id = 0;
	t_id = 0;

	for (i = 0; i < MAX; i ++) {
		for (j = 0; j < MAX; j ++) {
			/*Create 9 threads of 3x3 submatrix*/
			if ((i % 3) == 0 && (j % 3) == 0) {
				arg_matrix[t_id] = (struct arg *) malloc (sizeof (struct arg));
				
				arg_matrix[t_id] -> row_index = i;
				arg_matrix[t_id] -> col_index = j;
				pthread_create (&tid[id ++], NULL, validate_submatrix, (void
							*)arg_matrix[t_id]);	
				t_id ++;
			}
			/*Create 9 threads for each row and each column*/
			if (j == 0) {
				arg_row[i] = (struct arg *) malloc (sizeof (struct arg));
				arg_col[i] = (struct arg *) malloc (sizeof (struct arg));

				arg_row[i] -> row_index = i;	
				arg_row[i] -> col_index = j;
				pthread_create (&tid[id++], NULL, validate_row, (void
							*)arg_row[i]);
				
				arg_row[i] -> row_index = j;
				arg_col[i] -> col_index = i;
				pthread_create (&tid[id++], NULL, validate_column, (void
							*)arg_col[i]);
			}

		}
	}	
	/*Wait for 27 threads to terminate and store the return status into
	 * valid[27]*/
	for (i = 0; i < NO_OF_THREADS; i ++) {
		pthread_join (tid[i], (void*)&valid[i]);
	}
#endif
	/*Display the result Sudoku solution is valid or invalid*/
	printf ("\n\n********** Result **********\n\n");
#if 0
	for (i = 0; i < NO_OF_THREADS; i ++) {
		if (valid[i] != 1) {
			printf ("Sudoku Solution is not valid!\n\n\n");
			flag = 0;
			break;
		}
	}
	if (flag == 1) {
		printf ("Sudoku solution is correct!\nGreat job!\n\n\n");
	}
	
	free (line);
	free (ch_num);
	for(i = 0; i < MAX; i ++) {
		free (arg_matrix[i]);
		free (arg_row[i]);
		free (arg_col[i]);
	}
#endif
	return 0;
}
