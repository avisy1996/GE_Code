#include "sudoku.h"
#if 0
static void free_memory (int *arg, int n)
{
	int i;
	for (i = 0; i < n; i ++) {
		free (arg[i]);
	}
	return;
}
static void terminate_threads (int *tid, int n)
{
	int i;
	for (i = 0; i < n; i ++) {
		pthread_cancel (tid[i]);
	}
	return;
}
#endif
int validate_sudoku (int *arr)
{
	int id = 0;
	int	t_id = 0;
	int i, j, k, status;
	char valid[NO_OF_THREADS];
	struct arg *arg_row [MAX] = { NULL };
	struct arg *arg_col [MAX] = { NULL };
	struct arg *arg_matrix [MAX] = { NULL };
	pthread_t tid[NO_OF_THREADS];

	for (i = MIN; i < MAX; i ++) {
		for (j = MIN; j < MAX; j ++) {
			/*Create 9 threads of 3x3 submatrix*/
			if ((i % SUB_MAX) == MIN && (j % SUB_MAX) == MIN) {
				arg_matrix[t_id] = (struct arg *) malloc (sizeof (struct arg));
				if (arg_matrix [t_id] == NULL) {
					return MALLOC_FAILED;
				}

				arg_matrix[t_id] -> row_index = i;
				arg_matrix[t_id] -> col_index = j;
				status = pthread_create (&tid[id ++], NULL, validate_submatrix, (void
							*)arg_matrix[t_id]);	
				if (status != INVALID) {
					return CREATE_THREAD_FAILED;
				}
				t_id ++;
			}
			/*Create 9 threads for each row and each column*/
			if (j == MIN) {
				arg_row[i] = (struct arg *) malloc (sizeof (struct arg));
				if (arg_row [t_id] == NULL) {
					return MALLOC_FAILED;
				}
				arg_col[i] = (struct arg *) malloc (sizeof (struct arg));
				if (arg_col [t_id] == NULL) {
					return MALLOC_FAILED;
				}

				arg_row[i] -> row_index = i;	
				arg_row[i] -> col_index = j;
				status = pthread_create (&tid[id++], NULL, validate_row, (void
							*)arg_row[i]);
				if (status != INVALID) {
					return CREATE_THREAD_FAILED;
				}
				
				arg_row[i] -> row_index = j;
				arg_col[i] -> col_index = i;
				status = pthread_create (&tid[id++], NULL, validate_column, (void
							*)arg_col[i]);
				if (status != INVALID) {
					return CREATE_THREAD_FAILED;
				}
			}
		}}
		
	/*Wait for 27 threads to terminate and store the return status into
	 * valid[27]*/
	for (i = MIN; i < NO_OF_THREADS; i ++) {
		pthread_join (tid[i], (void*)&valid[i]);
		if (valid[i] == MIN) {
			return INVALID;			
		}
	}
	return VALID;
}
