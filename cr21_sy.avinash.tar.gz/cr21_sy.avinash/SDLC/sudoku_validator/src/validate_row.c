#include "sudoku.h"

/*Validate each row of sudoku solution*/
void *validate_row (void *param) 
{
	struct arg *args;
	args = (struct arg *) param;

	int row_data[NO_OF_ENTRIES] = { 0 };
	int col_index, num;

	/*check 9 entries of perticular row*/
	for (col_index = args -> col_index; col_index < MAX; col_index ++) {
		num = arr[args -> row_index][col_index];
		
		/*if no from 1 to 9 is repeated then return immediately*/
		if (row_data[num] != 0) {
			return (void *)INVALID;
		}
		else {
			row_data[num] = 1;
		}
	}
	return (void *)VALID;
}
