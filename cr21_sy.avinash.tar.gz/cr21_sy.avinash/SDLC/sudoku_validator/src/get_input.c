#include "sudoku.h"

int get_input (char *filename, int *arr)
{
	FILE *fp = NULL;
	char *line = NULL;
	char *ch_num = NULL;
	int i = 0;
	int j, no;

	fp = fopen (filename, "r");		//Open the file in read mode
	if (fp <= 0) {
		perror ("Unable to open file\n");
		return 0;
	}

	line = (char *) malloc (MAX_SIZE);
	if (line == NULL) {
		return MALLOC_FAILED;
	}
	ch_num = (char *) malloc (MAX_SIZE);
	if (ch_num  == NULL) {
		return MALLOC_FAILED;
	}

	/*Copy the Sulution from into 9x9 matrix*/
	while (fgets (line, MAX_SIZE, fp) != NULL) {

		ch_num = strtok (line, " \n\t,");
		j = 0;
		while (ch_num != NULL) {
			no = my_atoi (ch_num);
			
			if (no == -1) {
				return INVALID_SUDOKU;
			}
			*((arr + i * MAX) + j)  = no;
			ch_num = strtok (NULL, " \n\t,");
			j ++;
		}

		/*Error if row in file has more than 9 entries*/
		if (j > MAX || j < MAX) {
			return INVALID_SUDOKU;
		}
		
		i ++;
	}

	/*Error if no of columns in file has more than 9 entries or less than 9
	 * entries*/
	if (i < MAX || i > MAX) {
		return INVALID_SUDOKU;
	}

	return VALID;
}
