#include "sudoku.h"

/*Validate each row of sudoku solution*/
void *validate_column (void *param) 
{
	struct arg *args;
	args = (struct arg *) param;

	int col_data[NO_OF_ENTRIES] = { 0 };
	int row_index, num;
	
	/*check 9 entries of perticular column*/
	for (row_index = args -> row_index; row_index < MAX; row_index ++) {
		num = arr[row_index][args -> col_index];

		/*if no from 1 to 9 is repeated then return immediately*/
		if (col_data[num] != 0) {
			return (void *)INVALID;
		}
		else {
			col_data[num] = 1;
		}
	}
	return (void *)VALID;
}
