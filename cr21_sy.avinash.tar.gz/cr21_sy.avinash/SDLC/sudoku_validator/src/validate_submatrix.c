#include "sudoku.h"
/*Validate 3x3 submatrix of sudoku solution*/
void *validate_submatrix (void *param) 
{
	struct arg *args;
	args = (struct arg *) param;

	int matrix_data[NO_OF_ENTRIES] = { 0 };
	int num, i, j;
	/*check entries in row starting from args -> row_index*/
	for (i = args -> row_index; i < args -> row_index + 3; i ++) {			
		/*check entries in column starting from args -> col_index*/
		for (j = args -> col_index; j < args -> col_index + 3; j ++) {
			num = arr[i][j];
			
			/*if no from 1 to 9 is repeated then return immediately*/
			if (matrix_data[num] != 0) { 				
				return (void *)INVALID;
			}
			else {
				matrix_data[num] = 1;
			}
		}
	}
	return (void *)VALID;	//Return valid on success
}
