#ifndef _SUDOKU_H
#define _SUDOKU_H 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <pthread.h>

#define MAX 9
#define MIN 0
#define SUB_MAX 3
#define MAX_SIZE 30 
#define NO_OF_ENTRIES 10
#define NO_OF_THREADS 27

//Error codes
#define FILE_OPEN_FAILED -1
#define MALLOC_FAILED -2
#define INVALID_SUDOKU -3
#define VALID 1
#define INVALID 0
#define CREATE_THREAD_FAILED -4
struct arg {
	int *row;
	int *col;
};

int arr[MAX][MAX];

int my_atoi (char *str);
void *validate_row (void *arg);
void *validate_column (void *arg);
void *validate_submatrix (void *arg);

#endif
