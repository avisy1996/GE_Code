#include "bst.h"

void postorder (node *p)
{
	if (p != NULL) {
		postorder (p -> left);
		postorder (p -> right);
		printf ("%d\t", p -> data);
	}
}
