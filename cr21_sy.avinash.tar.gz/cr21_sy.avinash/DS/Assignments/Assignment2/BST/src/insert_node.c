#include "bst.h"

node *insert_node (node *p, int key, int *status)
{
	if (p == NULL) {
		return create_node (key, status);
	}
	if (p -> data < key) {
		p -> right = insert_node (p -> right, key, status);
	}
	else if (p -> data > key) { 
		p -> left =  insert_node (p -> left, key, status);
	} 
	else {
		*status = FALSE;
		return p;
	}
	return p;
}
