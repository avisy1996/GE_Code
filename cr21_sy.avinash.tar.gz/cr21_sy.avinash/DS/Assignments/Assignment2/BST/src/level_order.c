#include "bst.h"

void level_order (node *root, queue **q)
{
	if (root != NULL) {
		enqueue (q, root -> data);
		printf ("%d\t", dequeue (q, root -> data));
		level
}
