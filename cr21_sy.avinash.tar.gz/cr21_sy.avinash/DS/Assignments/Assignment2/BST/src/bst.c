/* Program for implementation of Binary Search Tree*/
#include "bst.h"

int main (void)
{
	char str[MAX];
	int key;
	int ch; 
	static int status = FALSE;
	node *root = NULL;
	while(1)
	{

		printf ("\n**********************************\n\
	1. Insert to BST\n\
	2. Delete from BST\n\
	3. Inorder\n\
	4. Preorder\n\
	5. Postorder\n\
	6. Level order\n\
	8. Exit\n");
		printf ("Enter the choice : ");
		ch = my_atoi(fgets (str, MAX, stdin));
		
		switch (ch) {
		case 1:
			printf ("Enter data to be inserted : ");
			key = my_atoi (fgets (str, MAX, stdin));
			root = insert_node (root, key, &status);
			if(status) {
				printf ("%d inserted to tree!\n", key);
			}
			else {
				printf ("%d not inserted or already present in tree!\n", key);
			}
			break;
		case 2:
			printf ("Enter data to be deleted : ");
			key = my_atoi (fgets (str, MAX, stdin));
			root =  delete_node (root, key, &status);
			if(status) {
				printf ("%d deleted from tree!\n", key);
			}
			else {
				printf ("%d not deleted or not found in tree!\n", key);
			}
			
			break;	
		case 3:	
			inorder (root);		
			break;
		case 4:
			preorder (root);
			break;
		case 5:
			postorder (root);
			break;
		case 6:
			break;
		case 8:
			exit(0);
			break;
		default:
			printf("Wrong choice!\n");
		}
	}

	return 0;
}
