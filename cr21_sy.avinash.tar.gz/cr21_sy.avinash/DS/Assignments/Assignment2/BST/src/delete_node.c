#include "bst.h"

node *delete_node (node *p, int key, int *status )
{
	if (p == NULL)	{
		*status = FALSE;
		return p;
	}

	if (key < p -> data) {
		p -> left = delete_node (p -> left, key, status);
	}
	else if (key > p -> data) {
		p -> right = delete_node (p -> right, key, status);
	}
	else if (key == p -> data){
		*status =  TRUE;
		if (p -> left == NULL) {
			node *temp = p -> right;
			free (p);
			return temp;
		}
		else if (p -> right == NULL) {
			node *temp = p -> left;
			free (p);
			return temp;
		}
		else {
			node *temp = inorder_successor (p -> right);
			p -> data = temp -> data;
			p -> right = delete_node (p -> right, temp -> data, status);
		}
	}
	return p;
}
