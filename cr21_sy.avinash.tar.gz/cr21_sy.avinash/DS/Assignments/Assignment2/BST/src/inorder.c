#include "bst.h"

void inorder (node *p)
{
	if (p != NULL) {
		inorder (p -> left);
		printf ("%d\t", p -> data);
		inorder (p -> right);
	}
}
