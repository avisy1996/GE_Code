#include "bst.h"

node *inorder_successor (node *p)
{
	while (p -> left != NULL) {
		p = p -> left;
	}
	return p;
}
