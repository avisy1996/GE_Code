/* Program for implementation of Red Black Tree*/
#include "rbtree.h"

int main (void)
{
	char *str;
	int key;
	int ch; 
	int flag = 1;
	
	tree *root = NULL;
	tree *node = NULL;
	//printf ("pid = %d", getpid());
	//getchar();
	while(flag != 0)
	{

		printf ("\n**********************************\n\
	1. Insert to RB Tree\n\
	2. Delete from RB Tree\n\
	3. Inorder\n\
	4. Preorder\n\
	5. Postorder\n\
	8. Exit\n");
		printf ("Enter the choice : ");
		str = (char *) malloc (MAX);
		if (str != NULL)
			if (fgets (str, MAX, stdin) != NULL)
				ch = my_atoi(str);
		else 
			ch = 9;
		free (str);
		switch (ch) {
		case 1:
			printf ("Enter data to be inserted : ");
			str = (char *) malloc (MAX);
			if (str != NULL) {
				if (fgets (str, MAX, stdin) != NULL) {
					key = my_atoi (str);
					node = create_node (key);
					if (node != NULL) {
						root = BST_insert_node (root, node);
						root = fix_insert_violations (root, node);
					}
				}
			}
			free (str);
			break;
		case 2:
			if (root != NULL) {
				printf ("Enter data to be deleted : ");
				str = (char *) malloc (MAX);
				if (str != NULL) {
					if (fgets (str, MAX, stdin) != NULL) {
						key = my_atoi (str);
						root =  BST_delete_node (root, key);
					}
				}
				free (str);
			}
			break;	
		case 3:
			if (root != NULL)
				inorder (root);		
			break;
		case 4:
			if (root != NULL)
				preorder (root);
			break;
		case 5:
			if (root != NULL)
				postorder (root);
			break;
		case 8:
			flag = 0;
			break;
		default:
			printf("Wrong choice!\n");
		}
	}

	return 0;
}
