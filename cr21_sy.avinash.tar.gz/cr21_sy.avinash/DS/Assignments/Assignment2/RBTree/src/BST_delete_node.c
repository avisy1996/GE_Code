#include "rbtree.h"

tree *BST_delete_node (tree *root, int key)
{
    tree *gp, *parent, *node;
	gp = NULL;
	parent = NULL;
	node = NULL;
	if (root == NULL)	{
		return root;
	}
	else {
	    node = search_node (root, &parent, &gp, key); 

	    if (node == NULL)
	        return root;
		if (node -> left == NULL) {
			root = fix_delete_violations (root, node);
			if (node == root) {
				root = node -> right;
			}
			else if (node == parent -> left) {
				parent -> left = node -> right;
			} 
			else {
				parent -> right = node -> right;
			}
			free (node);
			return root;
		}
		else if (node -> right == NULL) {
			root = fix_delete_violations (root, node);
			if (node == root) {
				root = node -> left;
			}
			else if (node == parent -> left) {
				parent -> left = node -> left;
			} 
			else {
				parent -> right = node -> left;
			}
			free (node);
			return root;
		}
		else {
			tree *temp = inorder_successor (node -> right);
			int temp_data = temp -> data;
			root = BST_delete_node (root, temp -> data);
			node -> data = temp_data;
			/*temp = search_node (root, &parent, &gp, temp -> data);
			root = fix_delete_violations (root, temp);
			node -> data = temp -> data;
			node = temp;
			if (temp == parent -> left) {
				parent -> left = NULL;
			} 
			else {
				parent -> right = NULL;
			}*/
		}			
		//free (node);
	}
	return root;
}
