#include "rbtree.h"

void inorder (tree *p)
{
	if (p != NULL) {
		inorder (p -> left);
		printf ("%d %d\t", p -> data, p -> color);
		inorder (p -> right);
	}
}
