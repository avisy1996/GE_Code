#include "rbtree.h"

tree *rotate_left (tree *root)
{
	tree *temp = root -> right;
	root -> right = temp -> left;
	temp -> left = root;
	return temp;
}
