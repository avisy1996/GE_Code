#include "rbtree.h"

void postorder (tree *p)
{
	if (p != NULL) {
		postorder (p -> left);
		postorder (p -> right);
		printf ("%d %d\t", p -> data, p -> color);
	}
}
