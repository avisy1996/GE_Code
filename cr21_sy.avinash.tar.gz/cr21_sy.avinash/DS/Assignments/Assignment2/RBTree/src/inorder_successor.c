#include "rbtree.h"

tree *inorder_successor (tree *p)
{
	while (p -> left != NULL) {
		p = p -> left;
	}
	return p;
}
