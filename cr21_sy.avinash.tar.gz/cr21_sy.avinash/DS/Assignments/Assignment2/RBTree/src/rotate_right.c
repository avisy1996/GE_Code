#include "rbtree.h"
tree *rotate_right (tree *root)
{
	tree *temp = root -> left;
	root -> left = temp -> right;
	temp -> right = root;
	return temp;
}
