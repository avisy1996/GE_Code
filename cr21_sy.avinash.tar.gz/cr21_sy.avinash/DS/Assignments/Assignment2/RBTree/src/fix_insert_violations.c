#include "rbtree.h"

tree *fix_insert_violations (tree *root, tree *node)
{
	tree *parent;
	tree *gp;
	node = search_node (root, &parent, &gp, node -> data);
	if (node == root) {
		node -> color = BLACK;
	}
	else if (parent -> color == BLACK) {
		return root;
	}
	else if (parent -> color == RED) {
		if (parent == gp -> left) {
			if((gp -> right != NULL) && (gp -> right -> color == RED)) {	//L_1
				parent -> color = BLACK;
				gp -> right -> color = BLACK;
				gp -> color = RED;
				root = fix_insert_violations (root, gp);
			}
			else{											//L_2
				if (node == parent -> right) {				//L_2a
					gp -> left = rotate_left (parent);
					node = parent;
					parent = gp -> left;
				}
				if (node == parent -> left) {				//L_2b
					parent -> color = BLACK;
					gp -> color = RED;

					if (gp == root) {
						root = rotate_right (gp);
					}
					else {
						node = gp;
						node = search_node (root, &parent, &gp, node -> data);
						if (node == parent -> left)
							parent -> left = rotate_left (node);
						else
							parent -> right = rotate_left (node);
					}
				}
			}
		}
		else if (parent == gp -> right) {
			if((gp -> left != NULL) && (gp -> left -> color == RED)) {	//R_1
				parent -> color = BLACK;
				gp -> left -> color = BLACK;
				gp -> color = RED;
				root = fix_insert_violations (root, gp);
			}
			else{											//R_2
				if (node == parent -> left) {				//R_2a
					gp -> right = rotate_right (parent);
					node = parent;
					parent = gp -> right;
				}
				if (node == parent -> right) {				//R_2b
					parent -> color = BLACK;
					gp -> color = RED;

					if (gp == root) {
						root = rotate_left (gp);
					}
					else {
						node = gp;
						node = search_node (root, &parent, &gp, node -> data);
						if (node == parent -> left)
							parent -> left = rotate_left (node);
						else
							parent -> right = rotate_left (node);
					}
				}
			}
		}
	}
	return root;
}
