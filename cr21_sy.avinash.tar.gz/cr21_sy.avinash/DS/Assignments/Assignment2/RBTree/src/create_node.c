#include "rbtree.h"

tree *create_node (int key)
{
	tree *temp = (tree *) malloc (sizeof(tree));
	if (temp == NULL) {
		return NULL;
	}
	temp -> left = NULL;
	temp -> data = key;
	temp -> color = RED;
	temp -> right = NULL;
	
	return temp;
}
