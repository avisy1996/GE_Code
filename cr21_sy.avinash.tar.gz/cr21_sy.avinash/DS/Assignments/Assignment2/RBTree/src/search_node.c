#include "rbtree.h"

tree *search_node (tree *root, tree **parent, tree **gp, int key)
{
	*gp = *parent = NULL;
	while ((root -> data != key) && (root != NULL)) {
		*gp = *parent;
		*parent = root; 
		if (key < root -> data) {
			root = root -> left;
		}
		else {
			root = root -> right;
		}
	}
	return root;
}
