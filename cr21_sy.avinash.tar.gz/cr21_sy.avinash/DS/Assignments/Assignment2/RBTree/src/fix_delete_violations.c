#include "rbtree.h"

tree *fix_delete_violations (tree *root, tree *node)
{
    tree *parent, *gp, *sibling =  NULL;
    node = search_node (root, &parent, &gp, node -> data);
    if (node == NULL)
        return root;

    else if (node -> color == RED) {                //Case i
        return root;
    }

    else if (((node -> left == NULL && node -> right != NULL) ||
			(node -> right == NULL && node -> left != NULL)) 
			&& node -> color == BLACK) {					//Case v
        tree *temp;
        if (node -> right != NULL && node -> right -> color == RED) 
            temp = node -> right;
        else 
            temp = node -> left;
            
        temp -> color = BLACK;

        return root;
    }
    else {											//Case iv
        if (node == root) {
            return root;
        }

        if (node == parent -> left) {				//Case L
            sibling = parent -> right;

            if (sibling -> color == RED) {			//Case L_1
                parent -> color = RED;
                sibling -> color = BLACK;
                
				if (parent == root)
                    root = rotate_left (parent);
                else if (parent == gp -> right)
                    gp -> right = rotate_left (parent);
                else 
                    gp -> left = rotate_left (parent);

				node = search_node (root, &parent, &gp, node -> data);
				sibling = parent -> right;
            }
            if(sibling -> color == BLACK				//Case L_2
                && (sibling -> left == NULL || sibling -> left -> color == BLACK) 
                && (sibling -> right == NULL || sibling -> right -> color == BLACK)) {
                if (parent -> color == RED) {			//Case L_2a
                    sibling -> color = RED;
                    parent -> color = BLACK;
                    return root;
                }
                else {									//Case L_2b
                    sibling -> color = RED;
                    root = fix_delete_violations (root, parent);
                    return root;
                }
            }
            else if (sibling -> color == BLACK) {			//Case L_3
                if (sibling -> right == NULL || sibling -> right -> color == BLACK) {	//Case L_3a
                    sibling -> left -> color = BLACK;
                    sibling -> color = RED;
                    parent -> right = rotate_right (sibling);
					sibling = parent -> right;
                }
                if (sibling -> right != NULL && sibling -> right -> color == RED){	//Case L_3b
                    sibling -> color = parent -> color;
                    parent -> color = BLACK;
                    sibling -> right -> color = BLACK;
					if (parent == root)
						root = rotate_left (parent);
					else if (parent == gp -> right)
                        gp -> right = rotate_left (parent);
                    else 
                        gp -> left = rotate_left (parent);
					return root;
                }
            }
        }
		else {								//R
            sibling = parent -> left;

            if (sibling -> color == RED) {			//R_1
                parent -> color = RED;
                sibling -> color = BLACK;
                
				if (parent == root)
                    root = rotate_right (parent);
                else if (parent == gp -> right)
                    gp -> right = rotate_right (parent);
                else 
                    gp -> left = rotate_right (parent);

				node = search_node (root, &parent, &gp, node -> data);
				sibling = parent -> left;
            }
            if(sibling -> color == BLACK							//R_2
                && (sibling -> right == NULL || sibling -> right -> color == BLACK) 
                && (sibling -> left == NULL || sibling -> left -> color == BLACK)) {
                if (parent -> color == RED) {						//R_2a
                    sibling -> color = RED;
                    parent -> color = BLACK;
                    return root;
                }
                else {												//R_2b
                    sibling -> color = RED;
                    root = fix_delete_violations (root, parent);
                    return root;
                }
            }
            else if (sibling -> color == BLACK) {					//R_3
                if (sibling -> left == NULL || sibling -> left -> color == BLACK) {		//R_3a
                    sibling -> right -> color = BLACK;
                    sibling -> color = RED;
                    parent -> left = rotate_left (sibling);
					sibling = parent -> left;
                }
                if (sibling -> left != NULL && sibling -> left -> color == RED){		//R_3b
                    sibling -> color = parent -> color;
                    parent -> color = BLACK;
                    sibling -> left -> color = BLACK;
					if (parent == root)
						root = rotate_right (parent);
					else if (parent == gp -> right)
                        gp -> right = rotate_right (parent);
                    else 
                        gp -> left = rotate_right (parent);
					return root;
                }
                    
            }
        }

    }
    return root;
}

