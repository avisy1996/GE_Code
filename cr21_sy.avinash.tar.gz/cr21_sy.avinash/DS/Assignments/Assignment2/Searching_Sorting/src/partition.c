#include "Search_sort.h"

int partition (int *arr, int start, int end)
{
    int pivot, i, j;
    pivot = end;
    i = start - 1;
    j = start;
    while (j <= (end - 1)) {
        if (arr[j] <= arr[pivot]) {
            i ++;
            if (i != j) {
                swap (&arr[i], &arr[j]);
            }
        }
        j ++;
    }
    if ((i + 1) != pivot) {
        swap (&arr[i + 1], &arr[pivot]);
    }
    return i + 1;
}
