#include "Search_sort.h"

int linear_search (int *arr, int n, int key)
{
    int i;
    for (i = 0; i < n; i ++) {
        if (key == arr[i]) {
            return i;
        }
    }
    return -1;
}
