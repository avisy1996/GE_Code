#include "Search_sort.h"

void mergesort (int *arr, int start, int end)
{
	int mid;
	if (start < end) {
		mid = (start + end) / 2;

		mergesort (arr, start, mid);
		mergesort (arr, mid + 1, end);
		merge (arr, start, mid, end);
		printf("\n");
	}
}
