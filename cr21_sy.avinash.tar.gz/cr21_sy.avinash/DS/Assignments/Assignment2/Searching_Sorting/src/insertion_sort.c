#include "Search_sort.h"

void insertion_sort (int *arr, int n)
{
	int i, j, temp;
	j = 1;
	while (j < n) {
		temp = *(arr + j);
		for (i = j - 1; i >= 0 && temp < arr[i]; i --) {
			*(arr + (i + 1)) = *(arr + i);
		}
		*(arr +(i + 1)) = temp;
		j ++;
	}
}
