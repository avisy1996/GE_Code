/* Program for Sorting different sorting alogorithms*/
#include "Search_sort.h"

int main (void)
{
	char str[MAX];
	int arr[MAX], n;
	int ch;
	while(1)
	{

		printf ("\n\n**********Sorting**********\n\
    1. Bubble Sort\n\
    2. Insertion Sort\n\
    3. Selection Sort\n\
    4. Merge Sort\n\
    5. Quick Sort\n\
    6. Radix Sort\n\
    7. Heap Sort\n\n\
**********Searching**********\n\
    8. Linear Search\n\
    9. Binary Search\n\
    10. Exit\n");
		printf ("Enter the choide : ");
		ch = my_atoi(fgets(str, 10, stdin));
		
		switch (ch) {
		case 1:
			input(arr, &n);
			bubble_sort (arr, n);
			display_array (arr, n);
			break;
		case 2:
			input(arr, &n);
			insertion_sort (arr, n);
			display_array (arr, n);
			break;	
		case 3:	
			input(arr, &n);
			selection_sort (arr, n);
			display_array (arr, n);
			break;
		case 4:
			input(arr, &n);
			mergesort (arr, 0, n - 1);
			display_array (arr, n);	
			break;
		case 5:
			input(arr, &n);
			quicksort (arr, 0, n - 1);
			display_array (arr, n);			
			break;
		case 6:
				
			break;
		case 7:
			
			break;
		case 8:
		    {
		        int key, res;
		        input (arr, &n);
		        printf ("Enter key to Search : ");
                key =  my_atoi (fgets(str, MAX, stdin));
    		    res = linear_search (arr, n, key);
    		    if (res != -1) {
					printf ("%d found at index %d!", key, res + 1);
				}
				else {
					printf ("%d not found!", key);
				}
		    }
		    break;
		case 9:
		    {
		        int key, res;
		        input (arr, &n);
				printf ("Enter Sorted Array : ");
	    	    printf ("Enter key to Search : ");
                key =  my_atoi (fgets(str, MAX, stdin));
    		    res = binary_search (arr, 0, n-1, key);
    		    if (res != -1) {
					printf ("%d found at index %d!", key, res + 1);
				}
				else {
					printf ("%d not found!", key);
				}
		    }
		    break;
		case 10:
			exit(0);
			break;
		default:
			printf("Wrong choice!\n");
		}
	}

	return 0;
}
