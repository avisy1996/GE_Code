#include "Search_sort.h"

void display_array (int *arr, int n)
{
	int i;
	printf ("Sorted Array : ");
	for (i = 0; i< n; i ++) {
		printf ("%d ", *(arr + i));
	}
}
