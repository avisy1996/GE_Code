#include <stdio.h>
#include <stdlib.h>
#define MAX 100
#define EMPTY -1
#define TRUE 1
#define FALSE 0

void display_array (int *, int);
int my_atoi(char *);
void input (int *, int *);

int linear_search (int *, int, int);
int binary_search (int *, int, int, int);

void bubble_sort (int *, int);
void insertion_sort (int *, int);
void selection_sort (int *, int);
void mergesort (int *, int, int);
void merge (int *, int, int, int);
void swap (int *, int *);
void quicksort (int *, int, int);
int partition (int *, int, int);
