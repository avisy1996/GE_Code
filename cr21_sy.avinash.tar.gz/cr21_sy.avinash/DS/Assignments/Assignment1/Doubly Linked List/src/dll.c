#include "dll.h"
int main(void)
{
    int data = 0, num = 0, pos = 0, ch;
    char p[MAX], q[MAX];
    node *start = NULL;
    node *ptr = NULL;
    while (1) {
        ch = menu();
        switch(ch) {
            case 1:
                printf("\nEnter num to insert:");
                data = atoi(fgets(p, 3, stdin));
                insert_begin(&start,data);
                break;
            case 2:
                printf("\nEnter num to insert:");
                data = atoi(fgets(p, 3, stdin));
                insert_end(&start,data);
                break;
            case 3:
                printf("\nEnter num to insert:");
                data = atoi(fgets(p, 3, stdin));
                insert_mid(&start,data);
                break;
            case 4:
                printf("\nEnter num to search:");
                num = atoi(fgets(p, 3, stdin));
                ptr = search(&start, num);
                printf("\nEnter num to insert:");
                data = atoi(fgets(p, 3, stdin));
                insert_after_num(&start, ptr, data);
                break;
            case 5:
                printf("\nEnter num to search:");
                num = atoi(fgets(p, 3, stdin));
                ptr = search(&start, num);
                printf("\nEnter num to insert:");
                data = atoi(fgets(p, 3, stdin));
                insert_before_num(&start, ptr, data);
                break;
            case 6:
                printf("\nEnter pos:");
                pos = atoi(fgets(q, 3, stdin));
                printf("\nEnter num to insert:");
                data = atoi(fgets(p, 3, stdin));
                insert_after_pos(&start, pos, data);
                break;
            case 7:
                printf("\nEnter pos:");
                pos = atoi(fgets(q, 3, stdin));
                printf("\nEnter num to insert:");
                data = atoi(fgets(p, 3, stdin));
                insert_before_pos(&start, pos, data);
                break;
            case 8:
                printf("\nEnter pos:");
                pos = atoi(fgets(p, 3, stdin));
                printf("\nEnter num to insert:");
                data = atoi(fgets(q, 3, stdin));
                insert_pos(&start, pos, data);
                break;
            case 9:
                printf("\nEnter num to insert:");
                data = atoi(fgets(p, 3, stdin));
                insert_penul(&start, data);
                break;
            case 10:
                delete_begin(&start);
                break;
            case 11:
                delete_end(&start);
                break;
            case 12:
                printf("\nEnter num to search:");
                num = atoi(fgets(p, 3, stdin));
                delete_after_num(&start, num);
                break;
            case 13:
                printf("\nEnter num to search:");
                num = atoi(fgets(p, 3, stdin));
                delete_before_num(&start, num);
                break;
            case 14:
                printf("\nEnter num to search:");
                num = atoi(fgets(p, 3, stdin));
                delete_num(&start, num);
                break;
            case 15:
                delete_mid(&start);
                break;
            case 16:
                printf("\nEnter pos:");
                pos = atoi(fgets(q, 3, stdin));
                delete_after_pos(&start, pos);
                break;
            case 17:
                printf("\nEnter pos:");
                pos = atoi(fgets(q, 3, stdin));
                delete_before_pos(&start, pos);
                break;
            case 18:
                printf("\nEnter pos:");
                pos = atoi(fgets(q, 3, stdin));
                printf("\n pos:%d",pos); 
                delete_pos(&start, pos);
                break;
            case 19:
                delete_penul(&start);
                break;
            case 20:
                display (&start);
                break;
            case 21:
                delete_list(&start);
                exit(0);
                break;
            default:
                printf("\nInvalid choice\n");
                break;
        }
    }
    return 0;
}





