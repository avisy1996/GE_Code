#include "dll.h"

void insert_begin(node **s, int data)
{
    node *new;
    new = (node*)malloc(sizeof(node));
    new -> data = data;
    new -> prev = NULL;
    new -> next = *s;
    *s = new;
}


