#include "dll.h"

node* search(node **s, int data)
{
    node *t;
    if (*s == NULL)
        return NULL;
    else {
        t = *s;
        while ( t != NULL) {
            if ( t -> data == data)
                return t;
            t = t -> next;
        }
        return NULL;
    }
}

