#include "dll.h" 
void insert_after_num(node **s, node *ptr, int data)
{
    node *new;
    if (ptr == NULL) 
        printf("Invalid Insertion");
    else {
        new = (node*)malloc(sizeof(node));
        new -> data = data;
        new -> prev = ptr;
        new -> next = ptr -> next;
        if ( ptr -> next != NULL)
            ptr -> next -> prev = new;
        ptr-> next = new;
    }
}

