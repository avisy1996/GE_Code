#include "dll.h"                                             
void delete_pos(node **s, int pos)             
{                                                               
    node *t;                                             
    if (*s == NULL)                                             
        printf("Invalid Insertion");                            
    else {                                                      
        t = *s;
        printf("\n%d", pos);
        while (--pos && t)                                   
            t = t -> next; 
        delete_num(s, t -> data);
    }
}

