#include "dll.h"                                                        
int count(node **s)                                                    
{                                                                           
    int count = 0;                                                          
    node *t;                                                         
    if (*s == NULL) {                                                       
        printf("empty list");                                   
        return 0;                                                           
    }                                                               
    else {                                                              
        t = *s;                                                 
        while (t != NULL) {                                     
            count++;                                        
            t = t -> next;                                      
        }  
        return count;
    }   
}                                                                               
                      
