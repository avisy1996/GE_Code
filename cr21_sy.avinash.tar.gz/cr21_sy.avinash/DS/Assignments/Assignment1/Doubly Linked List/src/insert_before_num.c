#include "dll.h" 
void insert_before_num(node **s, node *ptr, int data)
{
    node *new;
    if (ptr == NULL) 
        printf("Invalid Insertion");
    else {
        new = (node*)malloc(sizeof(node));
        new -> data = data;
        new -> prev = ptr -> prev;
        new -> next = ptr;
        //first node
        if (ptr -> prev == NULL) {
            (*s) = new;
            ptr -> prev = new;
        }
        else {
            ptr -> prev -> next = new;
            ptr -> prev = new;
        }
    }
}





