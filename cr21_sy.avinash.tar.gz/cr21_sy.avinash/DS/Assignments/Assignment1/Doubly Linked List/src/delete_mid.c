#include "dll.h"                                                
void delete_mid(node **s)                          
{                                                               
    int mid;                                                
    if (*s == NULL)                                 
        printf("\nlist is empty");                          
    else {                                          
        mid = count(s) / 2;
        delete_after_pos(s, mid);
    }
}

