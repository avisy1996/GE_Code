#include "dll.h"                    
void insert_before_pos(node **s, int pos, int data)                 
{
    node *t;
    if (*s == NULL)
        printf("Invalid Insertion");
    else {                                                          
        t = *s;
        pos--;
        while (--pos) 
            t = t -> next;
        insert_before_num(s, t, data);
    }
}

