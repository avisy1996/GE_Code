#include "dll.h" 
int display(node **s)                 
{
    int count = 0;
    node *t;
    if (*s == NULL) {
        printf("empty list");
        return 0;
    }
    else {                                                          
        t = *s;
        while (t != NULL) {
            printf("%d ", t -> data);
            count++;
            t = t -> next;
        }
        return count;
    }
}

