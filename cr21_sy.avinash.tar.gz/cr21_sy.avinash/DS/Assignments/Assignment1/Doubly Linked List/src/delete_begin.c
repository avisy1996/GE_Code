#include "dll.h" 

int delete_begin(node **s)
{
    node *t;
    if ( *s == NULL)
        return 0;
    else {
        t = *s;
        (*s) = (*s) -> next;
        (*s) -> prev = NULL;
        free(t);
        return 1;
    }
}

