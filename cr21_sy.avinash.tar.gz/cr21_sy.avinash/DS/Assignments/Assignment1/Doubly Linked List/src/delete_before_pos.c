#include "dll.h"                                             
void delete_before_pos(node **s, int pos)         
{                                                           
    node *t;                                             
    if (*s == NULL)                                         
        printf("Invalid Insertion");                            
    else {                                                  
        t = *s;                     
        pos--;                                              
        while (--pos)                               
            t = t -> next; 
        delete_num(s, t -> data);
    }
}

