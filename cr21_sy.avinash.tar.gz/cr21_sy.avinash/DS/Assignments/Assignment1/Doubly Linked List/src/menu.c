#include "dll.h"

int menu(void)
{
    int choice;
    char str[MAX];
    printf("\n*********Insert Operation**********\n\
1.Insert at beagin\n2.Insert at end\n3.Insert mid\n\
4.Insert after num\n5.Insert before num\n6.Insert after pos\n\
7.Insert before pos\n8.Insert at pos\n9.Insert penultimate node\n\n\
**********Delete Operation*********\n\
10.Delete at begin\n11.Delete at end\n12.Delete after num\n\
13.Delete before num\n14.Delete num\n15.Delete mid\n16.Delete after pos\n\
17.Delete before pos\n18.Delete pos\n19:Delete penultimate\n\n\
20.Display list\n21.Exit\n");
    printf("\nEnter your choice : ");
    choice = atoi(fgets(str, MAX, stdin));
    return choice;
}

