#include "dll.h"                                                 
void insert_after_pos(node **s, int pos, int data)  
{    
    node *t;
   
    if (*s == NULL)                            
        printf("Invalid Insertion");                        
    else {  
        t = *s;
        while (--pos) 
            t = t -> next;
        insert_after_num(s, t, data);
    }

}

