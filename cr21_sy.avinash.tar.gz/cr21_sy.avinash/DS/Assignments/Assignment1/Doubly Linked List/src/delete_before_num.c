#include "dll.h"
int delete_before_num(node **s, int num)
{
    node *ptr;
    if ( *s == NULL)
        return 0;
    ptr = search(s, num);
    //first node
    if ( ptr -> prev == NULL) 
        return 0;
    ptr = ptr -> prev;
    if ( ptr -> prev != NULL)
        ptr -> prev -> next = ptr -> next;
    ptr -> next -> prev = ptr -> prev;
    free(ptr);
    return 1;
}


   


