#include "dll.h"

void insert_end(node **s, int data)
{
    node *new, *t;
    new = (node*)malloc(sizeof(node));
    new -> data = data;
    new -> next = NULL;
    if (*s == NULL) {
        new -> prev = NULL;
        *s = new;
    }
    else {
        t = *s;
        while (t -> next != NULL) 
            t = t -> next;
        new -> prev = t;
        t -> next = new;
    }    
}

