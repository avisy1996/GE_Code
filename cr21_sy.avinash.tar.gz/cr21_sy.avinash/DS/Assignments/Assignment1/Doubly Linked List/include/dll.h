#include <stdio.h>
#include <stdlib.h>

#define MAX 50
#define SIZE 5
#define TRUE 1
#define FALSE 0
typedef struct node {
    struct node *prev;
    char data;
    struct node *next;
}node;

node* search(node **s, int data);
void insert_begin(node **s, int data);
void insert_end(node **s, int data);
void insert_after_num(node **s, node *ptr, int data);
void insert_before_num(node **s, node *ptr, int data);
void insert_after_pos(node **s, int pos, int data);
void insert_before_pos(node **s, int pos, int data);
void insert_pos(node **s, int pos, int data);
void insert_penul(node **s, int data);
void insert_mid(node **s, int data);

int delete_begin(node **s);
int delete_end(node **s);
int delete_after_num(node **s,int num);
int delete_before_num(node **s, int num);
int delete_num(node **s, int num);
void delete_pos(node **s, int pos);
void delete_after_pos(node **s, int pos);
void delete_before_pos(node **s, int pos);
void delete_mid(node **s);
void delete_penul(node **s);
int delete_list(node **s);

int count(node **s);
int display(node **s);
int menu(void);

