#include "circular_doubly.h"

int isEmpty(NODE* start)
{
	NODE p;
	p = *start;
	if (p == NULL) {		
		return 1;
	} else {
		return 0;
	}
}

int i_at_start(NODE* start, NODE *last, int num)
{
	NODE temp = malloc(sizeof(SLL));
	temp->data = num;
	temp->next = NULL;
	temp->prev = NULL; 
	*start = temp;
	*last = temp;
	return 1;
}

int i_at_begin(NODE* start, NODE *last, int num)
{
	NODE temp = malloc(sizeof(SLL));
	NODE p = *start;
	NODE l = *last;

	temp->data = num;
	temp->next = NULL;
	temp->prev = NULL;

	temp->next = *start;
	p->prev = temp;
	*start = temp;	
	l->next = temp;

	return 1;
}

int i_at_end(NODE *start, NODE *last, int num)
{
	NODE tmp = malloc(sizeof(SLL));	
	tmp->data = num;
	NODE s = malloc(sizeof(SLL));
	s = *start;
	NODE l = malloc(sizeof(SLL));
	l = *last;

	 s->prev = l;
	 tmp->next = s;
	 s->prev = tmp;
	 tmp->prev = l;
	 l->next = tmp;
	return 1;
}

int i_at_pos(NODE* start, int num, int pos)
{
	int i = 1;
	NODE p = malloc(sizeof(SLL));
	p = *start;
	NODE temp = malloc(sizeof(SLL));	
	temp->data = num;
	temp->next = NULL;
	temp->prev = NULL;
	for (i = 0;i < (pos-1);i++) {
	p = p->next;
	}	
	temp->next = p->next;
	temp->prev = p;
	p->next->prev = temp;
	p->next = temp;
	return 1;
}

int i_after_pos(NODE* start, int num, int pos)
{
	int i = 1;
	NODE p;
	p = *start;
	NODE temp = malloc(sizeof(SLL));	
	temp->data = num;
	temp->next = NULL;
	temp->prev = NULL;
	for (i = 0;i < (pos+1);i++) {
	p = p->next;
	}	
	temp->next = p->next;
	temp->prev = p;
	p->next->prev = temp;
	p->next = temp;
	return 1;
}

int i_before_num(NODE* start, int num, int key)
{
	int i = 1;
	NODE p;
	p = *start;
	NODE temp = malloc(sizeof(SLL));	
	temp->data = num;
	temp->next = NULL;
	temp->prev = NULL;
	while(p->data != key) {
	p = p->next;
	i++;
	}	
	temp->next = p->next;
	temp->prev = p;
	p->next->prev = temp;
	p->next = temp;
	return 1;
}

int i_after_num(NODE* start, int num, int key)
{
	int i = 1;
	NODE p;
	p = *start;
	NODE temp = malloc(sizeof(SLL));	
	temp->data = num;
	temp->next = NULL;
	temp->prev = NULL;
	while(p->data != key) {
	p = p->next;
	i++;
	}	
	temp->next = p->next;
	temp->prev = p;
	p->next->prev = temp;
	p->next = temp;
	return 1;
}

int i_at_mid(NODE* start, NODE *last, int num)
{
	
	int size1, i = 1;
	NODE temp;
	NODE l= *last;
	NODE p = malloc(sizeof(SLL));
	p = *start;
	temp = *start;
	NODE temp1 = malloc(sizeof(SLL));
	temp1->data = num;
	temp1->next = NULL;
	temp1->prev = NULL;
	size1= size(&p, &l);
	size1 = size1/2;
	while(i != size1) {
		temp = temp->next;
		i++;
	}
	temp1->next = temp->next;
	temp->prev = temp1;
	temp->next = temp1;
	return 1;

}

int i_Penultimate(NODE* start, int num) 
{
	NODE p = malloc(sizeof(SLL));
	p = *start;
	NODE q; 
	q = *start;	
	NODE temp = malloc(sizeof(SLL));	
	temp->data = num;
	temp->next = NULL;
	temp->prev = NULL;	
	while (p->next != NULL) {
		q = p;
		p = p->next;
	} 
	temp->next = q->next;
	q->next->prev = temp;
	q->next = temp;
	return 1;

}

void display(NODE* start, NODE *last)
{
	NODE p = malloc(sizeof(SLL));
	p = *start;
	NODE l = *last;
	while (p != l) {
		printf("\t%d\t", p->data);
		p = p->next;
	}
	printf("\t%d\t", p->data);
}

int size(NODE* start, NODE* last) 
{
	int size1 = 0;
	NODE l = *last;
	NODE p = malloc(sizeof(SLL));
	p = *start;
	while (p != l ) {
		size1++;
		p = p->next; 	
	}
	return size1;
}
