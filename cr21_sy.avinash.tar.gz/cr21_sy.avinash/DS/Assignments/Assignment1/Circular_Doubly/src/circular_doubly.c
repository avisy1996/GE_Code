#include "circular_doubly.h"
int main(void)
{
	NODE start, last;
	start = NULL;
	last = NULL;
	int num, pos;
	char *num1 = (char *) malloc (sizeof(int));
	char *pos1 = (char *) malloc (sizeof(int)); 
	int status;
	char *ch1 = (char *) malloc (sizeof(int));
	char *ch2 = (char *) malloc (sizeof(int));
	
	do {
		printf("\n1.INSERT\n2.DELETE\n3.DISPLAY\n4.SIZE\n5.EXIT\n");
		printf("\nEnter choice: \n");
		fgets(ch1, MAX, stdin);

		switch (atoi(ch1)) {
		case 1:	printf("\nEnter number: \n");
			fgets (num1, MAX, stdin);
			num = atoi(num1);
			printf("\n1.At beginning\n2.At end\n3.At position\n4.Before position\n5.After position\n6.Before number\n7.After number\n8.At mid\n9.At penultimate node.\n");		
			
			printf("\nEnter choice: \n");
			fgets(ch2, MAX, stdin);

			switch (atoi(ch2)) {
			case 1:
				status = isEmpty(&start);
				if (status == 1) {
					status = i_at_start(&start, &last, num);
				}else {
					status = i_at_begin(&start, &last, num);
				}
				if(status == 1) {
					printf("\nSuccess..\n");
				} else {
					printf("\nfailed...\n");
				}
				break;							
			case 2:
				status = isEmpty(&start);
				if (status == 1) {
					status = i_at_start (&start, &last, num);
				} else {
					status = i_at_end (&start, &last, num);
				} 

				if(status == 1) {
					printf("\nSuccess..\n");
				} else {
					printf("\nfailed...\n");
				}
				break;

			case 3:
				status = isEmpty(&start);
				if (status == 1) {
					status = i_at_start(&start, &last, num);
				} else {
					printf("\nEnter position: \n");
					pos1 = fgets (pos1, MAX, stdin);
					pos = atoi(pos1);
					status = i_at_pos(&start, num, pos);
				}

				if(status == 1) {
					printf("\nSuccess..\n");
				} else {
					printf("\nfailed...\n");
				}
				break;
			case 4:
				status = isEmpty(&start);
				if (status == 1) {
					status = i_at_start(&start, &last, num);
				} else {
					printf("\nEnter position: \n");
					pos1 = fgets (pos1, MAX, stdin);
					pos = atoi(pos1);
					status = i_at_pos(&start, num, pos);
				}

				if(status == 1) {
					printf("\nSuccess..\n");
				} else {
					printf("\nfailed...\n");
				}
				break;
			case 5:
				status = isEmpty(&start);
				if (status == 1) {
					status = i_at_start(&start, &last, num);
				} else {
					printf("\nEnter position: \n");
					pos1 = fgets (pos1, MAX, stdin);
					pos = atoi(pos1);
					status = i_after_pos(&start, num, pos);
				}

				if(status == 1) {
					printf("\nSuccess..\n");
				}else {
					printf("\nfailed...\n");
				}
				break;
			case 6:
				status = isEmpty(&start);
				if (status == 1) {
					status = i_at_start(&start, &last, num);
				} else {
					printf("\nEnter key: \n");
					pos1 = fgets (pos1, MAX, stdin);
					pos = atoi(pos1);
					status = i_before_num(&start, num, pos);
				}
				if(status == 1) {
					printf("\nSuccess..\n");
				} else {
					printf("\nfailed...\n");
				}
				break;
			case 7:
				status = isEmpty(&start);
				if (status == 1) {
					status = i_at_start(&start, &last, num);
				}else {
					printf("\nEnter key: \n");
					pos1 = fgets (pos1, MAX, stdin);
					pos = atoi(pos1);

					status = i_after_num(&start, num, pos);
				}
				if(status == 1) {
					printf("\nSuccess..\n");
				} else {
					printf("\nfailed...\n");
				}
				break;
			case 8:
				status = isEmpty(&start);
				if (status == 1) {
					status = i_at_start(&start, &last, num);
				} else {
					status = i_at_mid(&start, &last, num);
				}
				if(status == 1) {
					printf("\nSuccess..\n");
				} else {
					printf("\nfailed...\n");
				}
				break;
			case 9:
				status = isEmpty(&start);
				if (status == 1) {
					status = i_at_start(&start, &last, num);
				}
				else {
					status = i_Penultimate(&start, num);
				}
				if(status == 1) {
					printf("\nSuccess..\n");
				}
				else {
					printf("\nfailed...\n");
				}
				break;

			default: 
				printf("\nWrong choice\n");
				break;
			}
			break;

		case 2:			
			printf("\n1.At beginning\n2.At end\n3.At position\n4.Before position\n5.After position\n6.Before number\n7.After number\n8.At mid\n9.At penultimate node.\n");
					
			printf("\nEnter choice: \n");
			fgets(ch2, MAX, stdin);

			switch (atoi(ch2)) {
				case 1:
					status = isEmpty(&start);
					if (status == 1) {
						printf("\nlinked list empty...");
					} else {
						status = d_at_begin(&start, &last);
					}
					if(status == 1) {
						printf("\nSuccess..\n");
					} else {	
						printf("\nfailed...\n");
					}
					break;
				case 2:
					status = isEmpty(&start);
					if (status == 1) {
						printf("\nlinked list empty...");
					} else {
						status = d_at_end(&start, &last);
					}	
					if(status == 1) {
						printf("\nSuccess..\n");
					} else {		
						printf("\nfailed...\n");
					}
					break;
				case 3:
					status = isEmpty(&start);
					if (status == 1) {
						printf("\nlinked list empty...");
					} else {
						printf("\nEnter position: \n");
						pos1 = fgets (pos1, MAX, stdin);
						pos = atoi(pos1);
						status = d_at_pos(&start, pos);
					}
					if(status == 1) {
						printf("\nSuccess..\n");
					}
					else {		
						printf("\nfailed...\n");
					}
					break;
				case 4:
					status = isEmpty(&start);
					if (status == 1) {
						printf("\nlinked list empty...");
					} else {
						printf("\nEnter position: \n");
						pos1 = fgets (pos1, MAX, stdin);
						pos = atoi(pos1);
						status = d_before_pos(&start, pos);
					}
					if(status == 1) {
						printf("\nSuccess..\n");
					} else {		
						printf("\nfailed...\n");
					}
					break;
				case 5:
					status = isEmpty(&start);
					if (status == 1) {
						printf("\nlinked list empty...");
					} else {
						printf("\nEnter position: \n");
						pos1 = fgets (pos1, MAX, stdin);
						pos = atoi(pos1);
						status = d_after_pos(&start, pos);
					}
					if(status == 1) {
						printf("\nSuccess..\n");
					} else {		
						printf("\nfailed...\n");
					}
					break;
				case 6:
					status = isEmpty(&start);
					if (status == 1) {
						printf("\nlinked list empty...");
					} else {
						printf("\nEnter position: \n");
						pos1 = fgets (pos1, MAX, stdin);
						pos = atoi(pos1);
						status = d_before_num(&start, pos);
					}
					if(status == 1) {
						printf("\nSuccess..\n");
					}
					else {				
						printf("\nfailed...\n");
					}
					break;
				case 7:
					status = isEmpty(&start);
					if (status == 1) {
						printf("\nlinked list empty...");
					} else {
						printf("\nEnter position: \n");
						pos1 = fgets (pos1, MAX, stdin);
						pos = atoi(pos1);
						status = d_after_num(&start, pos);
					}
					if(status == 1) {
						printf("\nSuccess...\n");
					} else {		
						printf("\nfailed...\n");
					}
					break;
				case 8:
					status = isEmpty(&start);
					if (status == 1) {
						printf("\nlinked list empty...");
					} else {
						status = d_at_mid(&start, &last);
					}
					if(status == 1) {
						printf("\nSuccess..\n");
					}
					else {		
						printf("\nfailed...\n");
					}
					break;
				case 9:
					status = isEmpty(&start);
					if (status == 1) {
						printf("\nlinked list empty...");
					} else {
						status = d_Penultimate(&start);
					}
					if(status == 1) {
						printf("\nSuccess..\n");
					}
					else {			
						printf("\nfailed...\n");
					}
					break;
				default: 
					printf("\nenter correctchoice\n");
					break;

			}
			break;
		
		case 3:
			status = isEmpty(&start);
			if (status == 1) {
				printf("\nlinked list empty...");
			} else {
				printf("\nstruct node-\n");
				display(&start, &last);
			}
			break;
		case 4:
			status = isEmpty(&start);
			if (status == 1) {
				printf("\nlinked list empty...");
			}else {
				printf("Size od SLL: %d", size(&start, &last));
			}
			break;		
		case 5:
			exit(0);
		default: 
			printf("\ncorrect choice:\n");
			break;
		}
	} while (ch1 != 0);

	return 0;

}

