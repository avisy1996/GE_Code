#define MAX 10
struct node
{
	int data;
	struct node *next;
	struct node *prev;
};
typedef struct node SLL;
typedef struct node* NODE;

//Functions to insert node into list
int isEmpty(NODE*);
int i_at_start(NODE*, NODE *, int);
int i_at_begin(NODE*, NODE *, int);
int i_at_end(NODE*, NODE *, int);
int i_at_pos(NODE*, int, int);
int i_Before_Pos(NODE*, int, int);
int i_after_pos(NODE*, int, int);
int i_before_num(NODE*, int, int);
int i_after_num(NODE*, int, int);
int i_at_mid(NODE*, NODE*, int);
int i_Penultimate(NODE*, int);

//Display and size
void display(NODE*, NODE*);
int size(NODE*, NODE*);

//Functions to delete node from list
int d_at_begin(NODE*, NODE*);
int d_at_end(NODE*, NODE*);
int d_before_pos(NODE*, int);
int d_at_pos(NODE*, int);
int d_after_pos(NODE*, int);
int d_before_num(NODE*, int);
int d_after_num(NODE*, int);
int d_at_mid(NODE*, NODE*);
int d_Penultimate(NODE*);

