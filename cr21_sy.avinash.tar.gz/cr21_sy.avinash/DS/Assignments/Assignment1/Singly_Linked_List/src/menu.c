#include "list.h"

int menu()
{
	int opt;
	char ch[MAX];
	printf("\n\n............Insert Node Option............\n");
	printf("\n1.Insert Begin\n2.Insert End\n3.Insert Node At Given Position");
	printf("\n4.insert Node before given position");
	printf("\n5.insert Node after given Position i");
	printf("\n6.Insert Number before Given Number"); 
	printf("\n7.Insert Number after Given Number");
	printf("\n8.Insert Node At Middle");
	printf("\n9.Insert Node At penultimate Node");
	printf("\n\n.............Delete Node Option...........\n");
	printf("\n10.Delete Begin");
	printf("\n11.Delete End");
	printf("\n12.Delete N position Node");
	printf("\n13.Delete before N Position Node");
	printf("\n14.Delete after N position Node");
	printf("\n15.Delete before NUM position Node");
	printf("\n16.Delete after NUM position Node");
	printf("\n17.Delete penultimate Node");
	printf("\n18.Delete At Middle");
	printf("\n19.Display");
	printf("\n20.EXIT ");
	printf("\nChoose Option::");
	opt = my_atoi (fgets (ch, MAX, stdin));
	return opt;
}

