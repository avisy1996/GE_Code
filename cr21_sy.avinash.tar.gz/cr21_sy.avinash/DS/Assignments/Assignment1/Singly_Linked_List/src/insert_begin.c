#include "list.h"

sll *insert_begin(sll *head)
{
	sll *ptr = create_node();
	if(head == NULL)
		head = ptr;
	else{
		ptr->next = head;
		head = ptr;
	}
	return (head);
}

