#include "list.h"

sll *delete_before_n_pos(sll *head , int pos )
{
	int i = 1;
	sll *prev_add = NULL;  
	sll *temp = NULL;
	if(head == NULL)
		printf("\nList Is empty");
	else{
			if(pos < 1 || pos >= node_count(head))
				printf("\nYour Position Is wrong");
			else{
					temp = head;
					while(i++ < pos){  
					     prev_add = temp;                 
   					     temp = temp->next;
					}  
					prev_add->next = temp->next;
					free(temp);
				}
		}	
	return head; 
}
