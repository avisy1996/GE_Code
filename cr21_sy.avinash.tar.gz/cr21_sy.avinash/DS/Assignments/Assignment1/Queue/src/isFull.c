#include <stdio.h>
#include <stdio.h>
#include "Queue.h"

int isFull (struct queue *q)
{
	if (q -> rear == MAX - 1)
		return TRUE;

	return FALSE;
}
