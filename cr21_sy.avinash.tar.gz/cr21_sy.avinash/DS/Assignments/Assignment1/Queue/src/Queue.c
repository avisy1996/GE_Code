/* Program to perform stack operations */

#include <stdio.h>
#include <stdlib.h>
#include "Queue.h"

int main (void)
{
	char str[MAX];
	int ch, no, status;
	struct queue q;
	q.front = q.rear = EMPTY;

	while(1)
	{

		printf ("\n==================\n1. Enqueue\n2. Dequeue\n3. Is Empty\n4. Is Full\n5. Front\n6. Rare\n7. Size of Queue\n8. Display\n9. Exit\n");
		printf ("Enter the choide : ");
		ch = my_atoi(fgets(str, 10, stdin));

		switch (ch) {
		case 1:
			printf("Enter Element to Enqueue : ");
			no = my_atoi(fgets(str, MAX, stdin));
			if (enqueue (&q, no)) {
				printf("\n%d Enqueued to Queue\n", no);
			}
			else {
				printf("\nQueue Overflow!\nFailed to enqueue %d to Queue\n", no);
			}	
			break;
		case 2:
			status = FALSE;
			no = dequeue (&q, &status);
			if (TRUE == status) {
				printf("\n%d dequeued from Queue\n", no);
			}
			else {
				printf("\nQueue Underflow!\n");
			}	
			break;	
		case 3:
			if (isEmpty(&q)) {
				printf ("\nQueue Underflow!\n");
			}
			else {
				printf ("\nQueue is not Empty!\n");
			}
			break;
		case 4:
			if (isFull(&q)) {
				printf ("\nQueue Overflow!\n");
			}
			else {
				printf ("\nQueue is not Full!\n");
			}
			break;
		case 5:
			if ((no = front (&q))) {
				printf("\n%d is front of Queue\n", no);
			}
			else {
				printf("\nQueue Underflow!\n");
			}	
			break;
		case 6:
			if ((no = rear (&q))) {
				printf("\n%d is rear of Queue\n", no);
			}
			else {
				printf("\nQueue Underflow!\n");
			}	
			break;
		case 7:
			if ((no = size(&q))) {
				printf ("\nSize of Queue = %d\n", no);
			}
			else {
				printf ("\nQueue Underflow!\n");
			}
			break;
		case 8:
			queue_display(&q);
			break;
		case 9:
			exit(0);
			break;
		default:
			printf("Wrong choice!\n");
		}
	}

	return 0;
}
