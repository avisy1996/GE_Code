#include <stdio.h>
#include <stdio.h>
#include "Queue.h"

int isEmpty (struct queue *q)
{
	if (((q -> front == EMPTY) && (q -> rear == EMPTY)) || (q -> rear < q
				-> front))
		return TRUE;

	return FALSE;
}
