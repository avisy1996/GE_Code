#include <stdio.h>
#include "Queue.h"

int dequeue (struct queue *q, int *status)
{
	int ele;
	if (isEmpty(q)) {
		*status = FALSE;
		return FALSE;
	}
	
	ele = q -> data [q -> front];
	if (q -> front == q -> rear) {
		q -> front = EMPTY;
		q -> rear = EMPTY;
	} 
	else {
		q -> front ++;
	}
	*status = TRUE;
	return ele;
}
