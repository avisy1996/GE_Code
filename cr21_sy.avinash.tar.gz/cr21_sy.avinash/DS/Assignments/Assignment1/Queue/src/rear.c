#include <stdio.h>
#include "Queue.h"

int rear (struct queue *q)
{
	if (isEmpty (q)) {
		return FALSE;
	}

	return q -> data[q -> rear];
}
