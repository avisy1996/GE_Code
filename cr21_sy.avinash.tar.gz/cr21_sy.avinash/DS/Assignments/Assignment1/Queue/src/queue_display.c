#include <stdio.h>
#include "Queue.h"

void queue_display (struct queue *q)
{
	int i = q -> front;
	if (isEmpty(q)) {
		printf ("\nQueue Underflow!\n");
	}
	
	printf ("\nContents of Queue: \n");
	while (q -> rear >= i) {
		printf ("%d\t", q -> data[i++]);
	}
	printf ("\n");
}
