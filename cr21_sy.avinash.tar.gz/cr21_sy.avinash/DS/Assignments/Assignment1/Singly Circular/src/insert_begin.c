#include "scll.h"

scll *insert_begin(scll *head)
{
	scll *ptr = create_node();
	if(head == NULL){
		head = ptr;
		ptr->next = head;
		return (head);
	} else if(head -> next == head) {
		ptr->next = head;
		head = ptr;
		head ->next ->next = ptr;
		return (head);
	} else{
		scll *last_node = head;
		while (last_node -> next != head) {
				last_node =last_node -> next;
		}
		last_node -> next = ptr;
		ptr->next = head;
		head = ptr;
		last_node = head;
		return (head);
	}
}

