#include "scll.h"

scll *insert_before_num_pos(scll *head , int num)
{
	scll *tmp_ptr = head;
	scll *prev_insert = NULL;
	scll *new_node = NULL;                                                       
    scll *next_insert = NULL;

	while(tmp_ptr != NULL){
		if(num == (tmp_ptr->data))
			break;
		else{
			prev_insert = tmp_ptr;
			tmp_ptr = tmp_ptr->next;
		}
	}
		
	if(tmp_ptr == NULL)
		printf("Your number Not Found In Linked List");
	else{
		if(prev_insert == NULL)
			head = insert_begin(head);
		else{
			new_node = create_node();                                                                      
        	next_insert = prev_insert->next;                                              
        	prev_insert->next = new_node;                                              
        	new_node->next = next_insert; 
		}
	}	
	return head;
}
