#include "scll.h"

scll *delete_begin(scll *head)
{
	scll *temp = head ;
	if(temp == NULL){
		printf("\nList Is Empty");
		return head;
	}else if(head -> next == head) {
		head = NULL;
		free(temp);
		return (head);
	}
	else{
		scll *last_node = NULL;
		last_node = getlast_node(head);
		last_node->next = temp->next;
		head = temp->next;
		free(temp);
	    return head;	
	}

}
