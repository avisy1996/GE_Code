#include "scll.h"

int node_count(scll *head)
{
	scll *temp = head;         
	int count = 0;
                                                   
    if(head == NULL)                                                            
        printf("Linked List is empty");                                         
    else{                                                                                                                       
        while(temp ->next != head){                                                    
			count++;                                                      
            temp = temp->next;                                                 
        }                                                                       
    }     
	return count;
}

