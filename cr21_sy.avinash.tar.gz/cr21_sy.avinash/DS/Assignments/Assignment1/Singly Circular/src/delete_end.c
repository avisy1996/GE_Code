#include "scll.h"

scll *delete_end(scll *head)
{
	scll *tmp_ptr;
	scll *prev_insert = NULL;
	if(head== NULL){
		printf("\nLinked List Is empty");
		return head;
	}
	else{
		if(head->next == head){
			tmp_ptr = head;
			head = NULL;
			free(tmp_ptr);
			return head;
		}
		else{
		      tmp_ptr = head;
			  while(tmp_ptr->next != head){                                                     
      			 prev_insert = tmp_ptr;                                                     
       			 tmp_ptr = tmp_ptr->next;                                                
    		 } 
			prev_insert->next = head;
			free(tmp_ptr);
			return head;
		}
	}
	
}
