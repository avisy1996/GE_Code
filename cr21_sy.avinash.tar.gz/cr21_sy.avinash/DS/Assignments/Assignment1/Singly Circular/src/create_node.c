#include "scll.h"

scll *create_node()
{
	int data = 0;
	scll *tmp_ptr = NULL;
	
	printf("\nEnter The Data:");
	scanf("%d",&data);
	if(NULL == ( tmp_ptr = (scll *)malloc(sizeof(scll)))){
		printf("\nMalloc Is failed...");
	}
	else{
		tmp_ptr->data = data;
		tmp_ptr->next = NULL;
	}
	return tmp_ptr;
}
