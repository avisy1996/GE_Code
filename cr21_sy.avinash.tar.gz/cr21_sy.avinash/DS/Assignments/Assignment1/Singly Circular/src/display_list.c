#include"scll.h"

void display_list(scll *head)
{
	scll *temp = head;
	if (head == NULL) {
		printf("Linked List is empty");
	}
	else{
		printf("\n\nData:");
		do {
			printf("%d ",temp->data);
			temp = temp ->next;
		} while (temp != head);
	}
}
