#include "scll.h"

scll *getlast_node(scll *head)
{
	scll *tmp_ptr = head;
	
	while(tmp_ptr->next != head)
		tmp_ptr = tmp_ptr -> next;
	return tmp_ptr;
}
