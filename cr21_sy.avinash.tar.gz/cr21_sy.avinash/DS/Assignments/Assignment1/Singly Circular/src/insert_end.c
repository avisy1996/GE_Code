#include "scll.h"

scll *insert_end(scll *head)
{
	scll *ptr = create_node();			
	scll *last_node = NULL;

	if (head == NULL) {
		head = ptr;
	}
	else {
		last_node = getlast_node(head);
		last_node->next = ptr;
		ptr->next = head;
	}
	return head;
}
