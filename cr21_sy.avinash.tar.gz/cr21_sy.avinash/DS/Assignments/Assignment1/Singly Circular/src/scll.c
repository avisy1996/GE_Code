#include <stdio.h>
#include <stdlib.h>
#include"scll.h"

int main(void)
{
	scll *head = NULL;   
	int opt = 0;			
	int pos = 0;		
	int num = 0;		
	char *pos_ptr = NULL;
	char *num_ptr = NULL;
	if(NULL == (pos_ptr = (char *)malloc(sizeof(char) * MAX)))
		printf("malloc Failed");
	if(NULL == (num_ptr = (char *)malloc(sizeof(char) * MAX)))
        printf("malloc Failed"); 
 	while(1){
		opt = menu();
		if(opt >=20)
			break;
		switch(opt){
			case 1:	
				head =  insert_begin(head);			   //Add Begin NODE
				break;
			case 2:
				head = insert_end(head);		    	   //Add End NODE
				break;
			case 3:	
				getchar();
				printf("Enter The Position");
				fgets(pos_ptr , MAX , stdin);
				pos = atoi(pos_ptr);		
				head = insert_n_pos(head , pos);	   //Insert nts position
				break;
		    case 4:
				getchar();
				printf("Enter The Position");
				fgets(pos_ptr , MAX , stdin);
				pos = atoi(pos_ptr);		
				head = insert_before_n_pos(head , pos); //Insert Node Before N pos
				break;
			case 5:
				getchar();
				printf("Enter The Position");
				fgets(pos_ptr , MAX , stdin);
				pos = atoi(pos_ptr);                                               
                head = insert_after_n_pos(head , pos); //Insert Node After N Pos                         
                break;
			case 6:
			 	getchar();
				printf("Enter The Number");
				fgets(num_ptr , MAX , stdin);
				num = atoi(num_ptr);                                               
                head = insert_before_num_pos(head , num); //Insert Befor Num Pos                          
                break;
			case 7:
				getchar();                                                      
                printf("Enter The Position");                                   
                fgets(num_ptr , MAX , stdin);                                      
                num = atoi(num_ptr);                                         
                head = insert_after_num_pos(head , num); //Insert After Num pos                       
                break;
			case 8:
				 head = insert_middle(head);             //Insert At Middle           
                 break;
			case 9:
				head = insert_penultimate_node(head);           //Insert Penultinate Node
				break;
			case 10:
				head = delete_begin(head);				//Delete Begin Node
				break;
			case 11:
				head = delete_end(head);				//Delete End Node
				break;
			case 12:
				getchar();                                                      
                printf("Enter The Position");                                   
                fgets(pos_ptr , MAX , stdin);                                      
                pos = atoi(pos_ptr);
				head = delete_n_pos(head , pos);		//delete n position Node
				break;
			case 13:
				getchar();                                                      
                printf("Enter The Position");                                   
                fgets(pos_ptr , MAX , stdin);                                      
                pos = atoi(pos_ptr);                                               
                head = delete_insert_before_n_pos(head ,--pos);       //delete Before n position Node
                break;
			case 14:
				getchar();                                                      
                printf("Enter The Position");                                   
                fgets(pos_ptr , MAX , stdin);                                      
                pos = atoi(pos_ptr);                                               
                head = delete_after_n_pos(head ,pos);       //delete after n position Node
                break;
			case 15:
				getchar();                                                      
                printf("Enter The Number");                                   
                fgets(num_ptr , MAX , stdin);                                      
                num = atoi(num_ptr);                                               
                head = delete_before_num_pos(head , num); //Delete Befor Num Pos                          
                break;
			case 16:
				getchar();                                                      
                printf("Enter The Number");                                   
                fgets(num_ptr , MAX , stdin);                                      
                num = atoi(num_ptr);                                               
                head = delete_after_num_pos(head , num); //Delete After Num Pos                          
                break; 
			case 17:
				head = delete_at_middle(head); 			//delete At Middle    
				break;
			case 18:
				head = delete_penultimate_node(head);  
				break;
			       
			case 19:
				display_list(head);						//Display list
				break;
		}  
	}
	return 0;
}
