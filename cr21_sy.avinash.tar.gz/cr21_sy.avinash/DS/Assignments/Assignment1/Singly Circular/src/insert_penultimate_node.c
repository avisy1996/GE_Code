#include "scll.h"

scll *insert_penultimate_node(scll *head)
{
	scll *new_node = NULL;                                                       
    scll *prev_insert = NULL;                                                       
    scll *next_insert = NULL;                                                       
    if(head == NULL)                                                
        printf("\nLinked List Is Empty\n");                  
    else{
		if(head->next == NULL)
			head = insert_begin(head);
		else{                                                                       
      		new_node = create_node();                                               
        	prev_insert = return_pos_node(head , (node_count(head)-1));                             
        	next_insert = prev_insert->next;                                              
        	prev_insert->next = new_node;                                              
        	new_node->next = next_insert;  
		}                                            
    }                                                                           
    return head;	
}
