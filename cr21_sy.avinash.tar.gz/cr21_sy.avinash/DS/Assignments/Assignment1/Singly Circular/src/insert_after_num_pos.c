#include "scll.h"

scll *insert_after_num_pos(scll *head , int num)                                  
{                                                                               
    scll *tmp_ptr = head;                                                     
    scll *new_node = NULL;                                                       
    scll *next_insert = NULL;                                                       
                                                                                
    while(tmp_ptr != NULL){                                                     
        if(num == (tmp_ptr->data))                                              
        	break;                                                              
        else                                                                  
           	tmp_ptr = tmp_ptr->next;                                                                            
    }                                                                           
    if(tmp_ptr == NULL)                                                         
        printf("Your number Not Found In Linked List");                         
    else{                                                                       
        if((tmp_ptr->next) == NULL)                                                    
            head = insert_end(head);                                             
        else{                                                                   
            new_node = create_node();                                           
            next_insert = tmp_ptr->next;                                          
            tmp_ptr->next = new_node;                                          
            new_node->next = next_insert;                                          
        }                                                                       
    }                                                                           
    return head;                                                                
}
