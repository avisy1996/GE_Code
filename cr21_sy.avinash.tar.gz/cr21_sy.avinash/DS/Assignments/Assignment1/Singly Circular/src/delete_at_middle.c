#include "scll.h"

scll *delete_at_middle(scll *head)
{
	int cnt = (node_count(head)/2);
	if(head == NULL)
		printf("\nList Is Empty");
	else
		head = delete_n_pos(head, cnt);  
	return head;
}
