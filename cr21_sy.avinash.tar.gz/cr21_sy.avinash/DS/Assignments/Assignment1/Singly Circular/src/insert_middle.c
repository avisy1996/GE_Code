#include "scll.h"

scll *insert_middle(scll *head)
{
	int cnt = (node_count(head)/2);
	if(head == NULL)
		printf("\nList Is Empty");
	else
		head = insert_after_n_pos(head, cnt);  
	return head;
}
