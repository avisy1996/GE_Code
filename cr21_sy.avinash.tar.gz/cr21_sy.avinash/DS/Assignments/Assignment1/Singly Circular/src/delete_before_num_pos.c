#include "scll.h"

scll *delete_before_num_pos(scll *head , int num)
{
	scll *prev_insert = NULL;  
	scll *temp = NULL;   
	if(head == NULL)
		printf("\nList Is empty");
	else{
		temp = head;
		while(temp != NULL){
			if((temp->next)->data == num)
				break;      
			prev_insert = temp;           
   			temp = temp->next;
		}
		if(temp == NULL)
			printf("\nNumber is Not Found In Linked List\n");  
		else{
			prev_insert->next = temp->next;
			free(temp);
		}
	}	
	return head; 
}
