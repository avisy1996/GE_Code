#include "scll.h"

scll *insert_after_n_pos(scll *head , int pos)
{
	scll *new_node = NULL;
	scll *prev_insert = NULL;
	scll *next_insert = NULL;
	if(pos > (node_count(head)))
		printf("\nSorry Your Given position Is Wrong.....\n");
	else{
		if(pos == (node_count(head)))
			insert_end(head);
		else{
			new_node = create_node();
			prev_insert = return_pos_node(head , pos);		
			next_insert = prev_insert->next;
			prev_insert->next = new_node;
			new_node->next = next_insert;
		}
	}
	return head;
}
