#include "scll.h"

scll *delete_after_num_pos(scll *head , int num)
{
	scll *temp = NULL;
	scll *prev_insert = NULL; 
	scll *next_insert = NULL;

	if(head == NULL)
		printf("\nList Is empty");
	else{
		temp = head;
		while(temp != NULL){
			if(temp->data == num)
				break;           
   			temp = temp->next;
		}
		if(temp == NULL)
			printf("\nNumber is Not Found In Linked List\n");  
		else{
			if(temp->next == NULL)
				printf("\nDeletion Not Possible Becasue Given Number is In last Node\n");
			else{
				prev_insert = temp;
				next_insert = prev_insert->next;
				prev_insert->next = next_insert->next;
				free(next_insert);
			}
		}
	}	
	return head; 
}
