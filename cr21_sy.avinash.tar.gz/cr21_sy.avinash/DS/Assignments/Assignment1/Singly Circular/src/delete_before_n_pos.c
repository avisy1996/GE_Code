#include "scll.h"

scll *delete_insert_before_n_pos(scll *head , int pos )
{
	int i = 1;
	scll *prev_insert = NULL;
	scll *temp = NULL;
	if(head == NULL)
		printf("\nList Is empty");
	else{
			if(pos < 1 || pos >= node_count(head))
				printf("\nYour Position Is wrong");
			else{
					temp = head;
					while(i++ < pos){  
					     prev_insert = temp;                 
   					     temp = temp->next;
					}  
					prev_insert->next = temp->next;
					free(temp);
				}
		}	
	return head; 
}
