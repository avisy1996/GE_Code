#include "scll.h"

scll *delete_penultimate_node(scll *head)
{
	scll *temp = NULL;                                                       
    scll *prev_insert = NULL;                                                       
    scll *next_insert = NULL;                                                       
    if(head == NULL)                                                
        printf("\nLinked List Is Empty\n");                  
    else{
		if(head->next == NULL)
			head = insert_begin(head);
		else{                                                                       
      		temp = head;
			while((temp->next)->next != NULL){
				prev_insert = temp;
				temp = temp->next;
			}
			next_insert = prev_insert->next;
			prev_insert->next = temp->next;
			free(next_insert);
		}                                            
    }                                                                           
    return head;	
}
