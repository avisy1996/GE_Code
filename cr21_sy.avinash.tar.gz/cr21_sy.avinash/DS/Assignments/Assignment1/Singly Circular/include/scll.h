#include<stdio.h>
#include<stdlib.h>

#define MAX 50

typedef struct s_list
{
	int data; 				
	struct s_list *next;	
}scll;



scll *getlast_node();	
scll *create_node();
void display_list(scll *);
int menu();
int node_count(scll *);
int my_atoi(char*);

scll* insert_begin(scll *);  
scll* insert_end(scll *);
scll* return_pos_node(scll * , int pos); 
scll* insert_n_pos(scll *, int pos);
scll* insert_before_n_pos(scll *, int pos);
scll* insert_after_n_pos(scll *, int pos);
scll* insert_before_num_pos(scll *, int num);
scll* insert_after_num_pos(scll *, int num);
scll* insert_middle(scll *);
scll* insert_penultimate_node(scll *); 


scll *delete_begin(scll *);
scll *delete_end(scll *);
scll *delete_n_pos(scll *, int);
scll *delete_insert_before_n_pos(scll *, int);
scll *delete_after_n_pos(scll *, int);
scll *delete_before_num_pos(scll *, int);
scll *delete_after_num_pos(scll *, int);
scll *delete_at_middle(scll *);
scll *delete_penultimate_node(scll *);


