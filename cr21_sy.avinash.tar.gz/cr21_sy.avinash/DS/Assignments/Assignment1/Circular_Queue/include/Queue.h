#include <stdio.h>
#include <stdlib.h>
#define MAX 10
#define EMPTY -1
#define TRUE 1
#define FALSE 0

struct queue 
{
	int data[MAX];
	int front;
	int rear;
};

int isFull (struct queue*);
int isEmpty (struct queue*);
int enqueue (struct queue*, int);
int dequeue (struct queue*, int *);
int front (struct queue*);
int rear (struct queue*);
int size (struct queue*);
void CQ_Display (struct queue*);
int my_atoi(char *);
