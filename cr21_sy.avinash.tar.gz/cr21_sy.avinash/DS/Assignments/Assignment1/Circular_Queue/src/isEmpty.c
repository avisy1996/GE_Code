#include "Queue.h"

int isEmpty (struct queue *q)
{
	if ((q -> front == EMPTY) && (q -> rear == EMPTY))
		return TRUE;

	return FALSE;
}
