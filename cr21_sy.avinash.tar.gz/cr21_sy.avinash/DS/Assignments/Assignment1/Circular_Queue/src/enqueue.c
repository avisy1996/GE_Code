#include "Queue.h"

int enqueue (struct queue *q, int ele)
{
	if (isFull (q)) {
		return FALSE;
	}
	if (isEmpty (q)) {
		q -> front = q -> front + 1;
		q -> rear = q -> rear + 1;
		q -> data [q -> rear] = ele;
		return TRUE;
	}
	else {
		q -> rear = (q -> rear + 1) % MAX;
		q -> data [q -> rear] = ele;
		return TRUE;
	}
}
