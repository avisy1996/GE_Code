#include "Queue.h"

int size (struct queue *q)
{
	if (isEmpty(q)) {
		return FALSE;
	}
	if (q -> rear >= q -> front) {
		return ((q -> rear % MAX) - (q -> front % MAX) + 1);
	}
	else {
		return (q -> rear + 1 + MAX - q -> front);
	}
}
