#include "Queue.h"

void CQ_Display (struct queue *q)
{
	int i = q -> front;
	if (isEmpty(q)) {
		printf ("\nQueue Underflow!\n");
		return;
	}
	
	printf ("\nContents of Queue: \n");
	if (q -> rear >= q -> front) {
		for (i = q -> front; i <= q -> rear; i++)
			printf ("%d\t", q -> data[i]);
	}
	else {
		for (i = q -> front; i < MAX; i++)
			printf ("%d\t", q -> data[i]);
		
		for (i = 0; i <= q -> rear; i++)
			printf ("%d\t", q -> data[i]);
	}
	printf ("\n");
}
