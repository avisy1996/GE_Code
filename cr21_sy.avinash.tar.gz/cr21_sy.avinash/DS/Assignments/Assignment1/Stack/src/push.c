#include <stdio.h>
#include "stack_operations.h"

int push (struct stack *s, int no)
{
	if (isFull (s -> top)) {
		return FALSE;
	}

	s -> top ++;
	s -> data [s -> top] = no;
	return TRUE;
}
