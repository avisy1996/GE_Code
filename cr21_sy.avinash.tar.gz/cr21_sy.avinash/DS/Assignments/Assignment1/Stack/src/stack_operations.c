/* Program to perform stack operations */

#include <stdio.h>
#include <stdlib.h>
#include "stack_operations.h"

int main (void)
{
	char str[MAX];
	int ch, no, status;
	struct stack s;
	s.top = EMPTY;
	while(1)
	{

		printf ("\n==================\n1. PUSH\n2. POP\n3. Is Empty\n4. Is Full\n5. Top of Stack\n6. Size of Stack\n7. Display\n8. Exit\n");
		printf ("Enter the choide : ");
		ch = my_atoi(fgets(str, 10, stdin));

		switch (ch) {
		case 1:
			printf("Enter No. to push on to stack : ");
			no = my_atoi(fgets(str, MAX, stdin));
			if (push (&s, no)) {
				printf("\n%d pushed to Stack\n", no);
			}
			else {
				printf("\nStack is Full!\n Failed to push %d to Stack\n", no);
			}	
			break;
		case 2:
			status = 0;
			no = pop (&s, &status);
			if (TRUE == status) {
				printf("\n%d poped from Stack\n", no);
			}
			else {
				printf("\nStack is Empty!\n");
			}	
			break;	
		case 3:
			if (isEmpty(s.top)) {
				printf ("\nStack is Empty!\n");
			}
			else {
				printf ("\nStack is not Empty!\n");
			}
			break;
		case 4:
			if (isFull(s.top)) {
				printf ("\nStack is Full!\n");
			}
			else {
				printf ("\nStack is not Full!\n");
			}
			break;
		case 5:
			if ((no = top (&s))) {
				printf("\n%d is at top of Stack\n", no);
			}
			else {
				printf("\nStack is Empty!\n");
			}	
			break;
		case 6:
			if ((no = size(&s))) {
				printf ("\nSize of Stack = %d\n", no);
			}
			else {
				printf ("\nStack is Empty!\n");
			}
			break;
		case 7:
			stack_display(&s);
			break;
		case 8:
			exit(0);
			break;
		default:
			printf("Wrong choice!\n");
		}
	}

	return 0;
}
