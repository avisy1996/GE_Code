#include <stdio.h>
#include "stack_operations.h"

int isFull (int top)
{
	if (top == MAX - 1) {		//Stack is full
		return TRUE;
	}
	else {
		return FALSE;
	}
}
