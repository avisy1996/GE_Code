#include <stdio.h>
#include "stack_operations.h"

void stack_display (struct stack *s)
{
	int i = 0;
	if (isEmpty(s -> top)) {
		printf ("\nStack is Empty!\n");
	}
	
	printf ("\nContents of Stack : \n");
	while (s -> top >= i) {
		printf ("%d\t", s -> data[i++]);
	}
	printf ("\n");
}
