#include <stdio.h>
#include "stack_operations.h"

int top (struct stack *s)
{
	if (isEmpty(s -> top)) {
		return FALSE;
	}

	return s -> data [s -> top];
}
