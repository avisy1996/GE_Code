#include <stdio.h>
#include "stack_operations.h"

int isEmpty (int top)
{
	if (top == EMPTY) {		//Stack is full
		return TRUE;
	}
	else {
		return FALSE;
	}
}
