#define MAX 100
#define EMPTY -1
#define TRUE 1
#define FALSE 0

struct stack 
{
	int data[MAX];
	int top;
};

int isFull (int);
int my_atoi(char *);
int push (struct stack*, int);
int pop (struct stack*, int *);
int isEmpty (int);
int top (struct stack*);
int size (struct stack*);
void stack_display (struct stack*);
