#ifndef __MATHOPS_H
#define __MATHOPS_H

extern int sum (int, int);
extern int diff (int, int);

#endif
