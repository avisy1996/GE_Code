#include "mathops.h"

int diff (int a, int b)
{
	int c;
	c = a - b;
	return c;
}
