#include "myelf.h"

void pgm_hdr_print(FILE *fp)
{
	int i;
	Elf32_Phdr phdr;
	Elf32_Ehdr ehdr;
	long offset;
	char str[1000];
	FILE *fptr = fp;
	fread (&ehdr, 52, 1, fp);

	fseek (fp, ehdr.e_phoff, SEEK_SET);
	printf ("\nElf file type is ");
	switch (ehdr.e_type) {
		case 0:
			printf ("NONE  (No file type)\n");
			break;
		case 1:
			printf ("REL (Relocatable file)\n");
			break;
		case 2:
			printf ("EXEC (Executable file)\n");
			break;
		case 3:
			printf ("DYN (Shared object file)\n");
			break;
		case 4:
			printf ("CORE (Core file)\n");
			break;
	}
	printf ("Entry point 0x%08x\n", ehdr.e_entry);
	printf ("There are %d program headers, starting at offset %d\n\n",
			ehdr.e_phnum, ehdr.e_phoff);
	printf ("Program Headers:\n");
	printf ("  %-14s %-8s %-10s %-10s %-8s %-8s %-3s %-5s\n", "Type", "Offset", "VirtAddr", 
			"PhysAddr", "FileSiz", "MemSiz", "Flg", "Align");
	for (i = 0; i < ehdr.e_phnum; i ++) {
		fread(&phdr, ehdr.e_phentsize, 1, fp);
		switch (phdr.p_type) {
			case 0:
				printf("  %-14s ", "NULL");
				break;
			case 1:
				printf("  %-14s ", "LOAD");
				break;
			case 2:
				printf("  %-14s ", "DYNAMIC");
				break;
			case 3:
				printf("  %-14s ", "INTERP");
				break;
			case 4:
				printf("  %-14s ", "NOTE");
				break;
			case 5:
				printf("  %-14s ", "SHLIB");
				break;
			case 6:
				printf("  %-14s ", "PHDR");
				break;
			case 0x6474e550:
				printf ("  %-14s ", "GNU_EH_FRAME");
				break;
			case 0x6474e551:  
				printf ("  %-14s ", "GNU_STACK");
				break;
			case 0x6474e552:
				printf ("  %-14s ", "GNU_RELRO");
				break;
		}
		printf ("0x%06x 0x%08x 0x%08x 0x%06x 0x%06x ", phdr.p_offset,
				phdr.p_vaddr, phdr.p_paddr, phdr.p_filesz, phdr.p_memsz);
		
		if (phdr.p_flags & 0x4) 
			printf ("R");
		else
			printf (" ");

		if (phdr.p_flags & 0x2) 
			printf ("W");
		else
			printf (" ");

		if (phdr.p_flags & 0x1) 
			printf ("E");
		else
			printf (" ");
		
		printf (" 0x%x\n", phdr.p_align);
		if (phdr.p_type == 3) {
			fgetpos(fp, &offset);
			char str[phdr.p_memsz];
			fseek (fp, phdr.p_offset, SEEK_SET);
			fread (&str, phdr.p_memsz, 1, fp);
			printf ("\t[Requesting program interpreter: %s]\n", str);
			fseek (fp, offset, SEEK_SET);
		}
	}
	fseek (fp, 0x34, SEEK_SET);
	fread (&str, 120, 1, fp);
	printf ("%s\n", str);
}

/*Print Section Header*/
void section_hdr_print (FILE *fp)
{
	int i; 
	Elf32_Addr shstrtab_off, shstroff;
	char shname[1000];
	Elf32_Shdr shdr;
	Elf32_Ehdr ehdr;

	fread (&ehdr, 52, 1, fp);

	shstrtab_off = ehdr.e_shoff + (ehdr.e_shentsize * ehdr.e_shstrndx);
	fseek (fp, shstrtab_off, SEEK_SET);
	fread (&shdr, 40, 1, fp);
	shstroff = shdr.sh_offset;
	
	fseek (fp, shstroff, SEEK_SET);
	fread (&shname, shdr.sh_size, 1, fp);
	
	fseek (fp, ehdr.e_shoff, SEEK_SET);
	printf ("There are %d section headers, starting at offset 0x%x:\n\n", ehdr.e_shnum, ehdr.e_shoff);
	printf ("Section Headers:\n");
	printf ("  %-5s%-19s%-16s%-9s%-7s%-7s%-3s%-4s%-3s%-4s%-2s\n", 
			"[Nr]", "Name", "Type", "Addr", "Off", "Size", "ES", "Flg", "Lk", "Inf", "Al");
	
	for (i = 0; i < ehdr.e_shnum; i ++) {
		fread (&shdr, 40, 1, fp);
		printf("  [%2d] ", i);
		if (i != 0) {
			printf ("%-19s", (shname + shdr.sh_name));
		} else {
			printf("%-19s", "");
		}
		switch (shdr.sh_type) {
			case 0:
				printf ("%-16s", "NULL");
				break;
			case 1:
				printf ("%-16s", "PROGBITS");
				break;
			case 2:
				printf ("%-16s", "SYMTAB");
				break;
			case 3:
				printf ("%-16s", "STRTAB");
				break;
			case 4:
				printf ("%-16s", "RELA");
				break;
			case 5:
				printf ("%-16s", "HASH");
				break;
			case 6:
				printf ("%-16s", "DYNAMIC");
				break;
			case 7:
				printf ("%-16s", "NOTE");
				break;
			case 8:
				printf ("%-16s", "NOBITS");
				break;
			case 9:
				printf ("%-16s", "REL");
				break;
			case 10:
				printf ("%-16s", "SHLIB");
				break;
			case 11:
				printf ("%-16s", "DYNSYM");
				break;
			case 14:
				printf ("%-16s", "INIT_ARRAY");
				break;
			case 15:
				printf ("%-16s", "FINI_ARRAY");
				break;
			case 0x6ffffff6:
				printf ("%-16s", "GNU_HASH");
				break;
			case 0x6fffffff:
				printf ("%-16s", "VERSYM");
				break;
			case 0x6ffffffe:
				printf ("%-16s", "VERNEED");
				break;
		}
		
		printf ("%08x %06x %06x %02x ", shdr.sh_addr, shdr.sh_offset, shdr.sh_size, shdr.sh_entsize);
		switch (shdr.sh_flags) {
			case 0:
				printf ("%3s ", "");
				break;
			case 1:
				printf ("%3s ", "W");
				break;
			case 2:
				printf ("%3s ", "A");
				break;
			case 3:
				printf ("%3s ", "WA");
				break;
			case 4:
				printf ("%3s ", "X");
				break;
			case 5:
				printf ("%3s ", "WX");
				break;
			case 6:
				printf ("%3s ", "AX");
				break;
			case 0x30:
				printf ("%3s ", "MS");
				break;
		}
		printf ("%-3d%-4d%-2d\n", shdr.sh_link, shdr.sh_info, shdr.sh_addralign); 
	}
	printf ("Key to Flags:\n");
	printf ("  W (write), W (write), A (alloc), X (execute), M (merge), S (strings)\n");
	printf ("  I (info), L (link order), G (group), T (TLS), E (exclude), x (unknown)\n");
	printf ("  O (extra OS processing required) o (OS specific), p (processor specific)\n");

}
void elfhdr_print (FILE *fp)
{
	int i;
	Elf32_Ehdr elf;
	fread (&elf, 52, 1, fp);
	printf ("\nELF Header:\n");
	printf ("  Magic:\t");
	for(i = 0; i < 16; i++) {
		printf ("%02x ",elf.e_ident[i]);
	}
	printf ("\n  Class:\t\t\t\t");
	switch (elf.e_ident[4]) {
		case 0:
			printf ("Invalid class\n");
			break;
		case 1:
			printf ("ELF32\n");
			break;
		case 2:
			printf ("ELF64\n");
			break;
	}
	printf ("  Data:\t\t\t\t\t");
	switch (elf.e_ident[5]) {
		case 0:
			printf ("Invalid data encoding\n");
			break;
		case 1:
			printf ("2's complement, little endian\n");
			break;
		case 2:
			printf ("2's complement, big endian\n");
			break;
	}
	printf ("  Version:\t\t\t\t");
	switch (elf.e_ident[6]) {
		case 0:
			printf ("0 (invalid ELF version)\n");
			break;
		case 1:
			printf ("1 (current)\n");
			break;
	}
	printf ("  OS/ABI:\t\t\t\t");
	switch (elf.e_ident[7]) {
		case 0:
			printf ("UNIX - System V\n");
			break;
	}
	printf("  ABI Version:\t\t\t\t%d\n", elf.e_ident[8]);
	printf ("  Type:\t\t\t\t\t");
	switch (elf.e_type) {
		case 0:
			printf ("NONE  (No file type)\n");
			break;
		case 1:
			printf ("REL (Relocatable file)\n");
			break;
		case 2:
			printf ("EXEC (Executable file)\n");
			break;
		case 3:
			printf ("DYN (Shared object file)\n");
			break;
		case 4:
			printf ("CORE (Core file)\n");
			break;
	}
	printf ("  Machine:\t\t\t\t");
	switch (elf.e_machine) {
		case 0:
			printf ("No machine\n");
			break;
		case 1:
			printf ("AT&T WE 32100\n");
			break;
		case 2:
			printf ("SPARC\n");
			break;
		case 3:
			printf ("Intel 80386\n");
			break;
		case 4:
			printf ("Motorola 68000\n");
			break;
		case 5:
			printf ("Motorola 88000\n");
			break;
		case 6:
			printf ("Intel 80860\n");
			break;
	}
	printf ("  Version:\t\t\t\t0x%x\n", elf.e_version);
	printf ("  Entry point address:\t\t\t0x%x\n", elf.e_entry);
	printf ("  Start of program headers:\t\t%d (bytes into file)\n", elf.e_phoff);
	printf ("  Start of Section headers:\t\t%d (bytes into file)\n", elf.e_shoff);
	printf ("  Flags:\t\t\t\t0x%x\n", elf.e_flags);
	printf ("  Size of this header:\t\t\t%d (bytes)\n", elf.e_ehsize);
	printf ("  Size of program header:\t\t%d (bytes)\n", elf.e_phentsize);
	printf ("  Number of program headers:\t\t%d\n", elf.e_phnum);
	printf ("  Size of section headers:\t\t%d (bytes)\n", elf.e_shentsize);
	printf ("  Number of section headers:\t\t%d\n", elf.e_shnum);
	printf ("  Section header string table index:\t%d\n", elf.e_shstrndx);
}
