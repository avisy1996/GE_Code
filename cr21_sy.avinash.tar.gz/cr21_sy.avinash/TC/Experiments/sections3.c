#include <stdio.h>
int fun1(void) 
{
	extern int e_ivar1;
	e_ivar1 = 20;
}
