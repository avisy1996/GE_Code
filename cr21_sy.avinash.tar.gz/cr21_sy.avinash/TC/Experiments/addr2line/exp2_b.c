void func (int *p)
{
	*p = 12;
	return;
}

