#include <string.h>
char *s;

int main()
{
	strcpy(s, "global edge");

	return 0;
}
