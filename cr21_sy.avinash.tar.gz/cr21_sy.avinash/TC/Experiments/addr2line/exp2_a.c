extern void func (int *);

int main()
{
	int *s;
	func (s);
	return 0;
}
