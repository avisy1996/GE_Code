#include <stdio.h>
#include <stdlib.h>

char *s;
FILE *fp;

int main()
{
	s = malloc(100);
	fp = fopen("exp4.c", "r");
	fread(s, 10, 1, fp);
	return 0;
}
