#include <stdio.h>
static int e_ivar1;
extern int g_ivar2;
int fun(void) 
{
	//e_ivar1 = 10;
	printf ("%d", g_ivar2);
	g_ivar2 = 20;
	return 0;
}
