#include <stdio.h>

int main(void) 
{
	char ch[4];
	ch[5] = 'a';
	return 0;
}
