int a;
int a=10;
int a=20;
int main()
{
	return 0;
}
