#include <stdio.h>
#include <stdlib.h>
#define MAX 10
const int c_ivar = 10;
int g_ivar1;
int g_ivar2 = 10;
static int sg_ivar1;
static int sg_ivar2 = 20;
//extern int e_ivar1;

int main()
{
	int f_ivar1;
	int f_ivar2 = 10;
	int *f_dvar1;
	static int sf_ivar1;
	static int sf_ivar2 = 10;

	//int e_ivar1 = 10;
	f_dvar1 = (int*)malloc(sizeof(int));
	fun();
	printf ("%d", g_ivar2);
	return 0;
}
