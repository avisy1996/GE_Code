#include <stdio.h>
int g_ivar1 = 10;

int fun(void) 
{
	return 0;
}
