#include "mathops.h"

int sum (int a, int b)
{
	int c;
	c = a + b;
	return c;
}
