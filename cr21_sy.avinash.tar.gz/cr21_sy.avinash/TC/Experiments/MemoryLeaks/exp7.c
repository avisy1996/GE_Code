#include <stdlib.h>

int main()
{
	double *p = malloc (sizeof(double) * 1000);
	free (p);
	return 0;
}
