#include <stdio.h>
int main()
{
	unsigned int a = 30, b = 20;
	unsigned int diff;
	diff = b - a;
	printf ("Diff is %d\n", diff);

	return 0;
}
