// exp mem allocation library should not identify the error but valgrind should
#include <stdlib.h>

int main()
{
	long double *a = malloc (sizeof(long double) * 10);
	long double *b = a + 3;
	free (b);
	free (a);
	return 0;
}
