#include <stdio.h>
#include <stdlib.h>

int main()
{
//	char x[10] = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '1'};
	char *x;
	x = (char*)malloc (10);
	x[11] = 'a';
	
	return 0;
}
