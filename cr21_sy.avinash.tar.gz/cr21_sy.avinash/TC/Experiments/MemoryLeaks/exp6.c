#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	char *greeting = malloc (1024);
	strcpy(greeting, "Dear");
	free (greeting);
	printf("%s Sir/Madam\n", greeting);

	return 0;
}
