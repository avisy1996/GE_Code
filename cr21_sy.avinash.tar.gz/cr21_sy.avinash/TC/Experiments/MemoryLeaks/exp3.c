#include <stdio.h>

int main (int argc, char **argv) 
{
	int x;
	if (argc > 666)
		x = 42;
	if (x == 0)
		printf ("x is zero\n");
	return 0;
}
