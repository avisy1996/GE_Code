#include <stdio.h>

int A, B, C;			//.common
int D = 12;				//.data
int E = 20;				//.data
static int F, G, H;		//.bss
static int I = 92;		//.data
static int J = 29;		//.data
const int M = 88;		//.rodata
const int N = 65;		//.rodata

extern void add (int, int);

int main()
{
	static int K = 24;	//.data
	static int L;		//.bss
	{
		static int F = 32;
		static int K = 33;
		printf ("%d\n", K);
	}
	

	A = 34;
	B = 19;
	C = 29;
	F = 62;
	G = 26;
	H = 18;

	add (2, 9);
	
	return 0;
}
