#ifndef _SLL_H
#define _SLL_H 1

#include <stdio.h>
#include <math.h>
#include <limits.h>
#define MAX 32

void nqueen (int row, int n);
int my_atoi (char *str);
#endif
