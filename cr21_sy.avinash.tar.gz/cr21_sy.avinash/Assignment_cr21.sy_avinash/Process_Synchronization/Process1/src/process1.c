/*	Name: process1.c
*	Author: Avinash Yadav
*	Date of Creation: 22/10/2018
*	Description: file with main() creates the shared memory region and and open the semaphore 
*		to achieve synchronization on shared memory.
*/
#include "process1.h"

int main (void)
{
	int shm;
	int buf [MAX] = {};
	void *map;	
	int i;
	sem_t *my_sem;

	/*Prepare the data to write into shared memroy*/
	for (i = 1; i <= 10; i ++) {
		buf[i-1] = time(NULL) % i;
	}

	/*Create shared memory*/
	shm = shm_open ("/my_shm", O_CREAT | O_TRUNC | O_RDWR, 777);
	if (shm == -1) {
		perror ("shm open : ");
	}

	/*allocate memory region for shared memory*/
	if (ftruncate (shm, LENGTH) == -1) {
		perror ("Truncate : ");
	}
	
	/*map the shared memory region to process*/
	map = mmap (NULL, LENGTH, PROT_READ | PROT_WRITE, MAP_SHARED, shm, 0);
	if(map == MAP_FAILED) {
		perror ("mmap : ");
	}

	/*create and open the semaphore*/
	if ((my_sem = sem_open ("/my_sem", O_CREAT, 666, 1)) == SEM_FAILED) {
		perror ("Semaphore open : ");
		return -1;
	}
	/*lock the semaphore to perform write operation on shared memory*/
	if (sem_wait (my_sem) == -1) {
		perror ("Semaphore wait : ");
		return -1;
	}
	
	/*Write data to shared memory*/
	if (write (shm, buf, sizeof(int) * MAX) == -1) {
		perror ("Write : ");
		return -1;
	}
	
	/*Sleep so that this process will wait until 2nd process comes for execution.
	* Sleep is used to demonstrate the example*/
	sleep (4);
	/*Once writing is done release the semaphore*/
	if (sem_post (my_sem) == -1) {
		perror ("Semaphore post : ");
		return -1;
	}
	/*Try to lock to read the updated data from shared memory*/
	if (sem_wait (my_sem) == -1) {
		perror ("Semaphore wait : ");
		return -1;
	}
	/*Read updated data from shared memory*/
	if (read (shm, buf, sizeof(int) * MAX) == -1) {
		perror ("Read : ");
	}

	/*Release semaphore*/
	if (sem_post (my_sem) == -1) {
		perror ("Semaphore post : ");
		return -1;
	}
	/*Print the data*/
	for (i = 0; i < 10; i ++) { 
		printf ("%d ", buf[i]);
	}

	/*Close the named semaphore*/
	sem_close (my_sem);
	/*remove the named semaphore*/
	sem_unlink ("/my_sem");

	/*Unmap the memory region*/
	munmap (map, LENGTH);	
	/*remove the shared memory*/
	shm_unlink ("/my_shm");

	return 0;
}
