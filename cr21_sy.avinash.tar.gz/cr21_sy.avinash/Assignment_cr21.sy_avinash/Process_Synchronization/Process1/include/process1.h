#ifndef _PROCESS1_H
#define _PROCESS1_H 1

#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#include <semaphore.h>

#define MAX 10
#define LENGTH 4096

#endif
