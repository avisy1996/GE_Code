/*	Name: process2.c
*	Author: Avinash Yadav
*	Date of Creation: 22/10/2018
*	Description: file with main() creates the shared memory region and and open the semaphore 
*		to achieve synchronization on shared memory.
*/
#include "process2.h"

int main (void)
{
	int shm;
	int buf [MAX];
	void *map;	
	int i;
	sem_t *my_sem;

	/*Open shared memory*/
	shm = shm_open ("/my_shm", O_RDWR , 777);	
	if (shm == -1) {
		perror ("shm open : ");
	}

	/*map the shared memory region to process*/
	map = mmap (NULL, LENGTH, PROT_READ | PROT_WRITE, MAP_SHARED, shm, 0);
	if(map == MAP_FAILED) {
		perror ("mmap : ");
	}
	/*create or open the semaphore*/
	if ((my_sem = sem_open ("/my_sem", O_CREAT, 666, 0)) == SEM_FAILED) {
		perror ("Semaphore create : ");
		return -1;
	}
	/*lock the semaphore to perform read and write operation on shared memory*/
	if (sem_wait (my_sem) == -1) {
		perror ("Semaphore wait : ");
		return -1;
	}
	/*Read data from shared memory*/
	if (read (shm, buf, sizeof(int) * MAX) == -1) {
		perror ("Read : ");
	}
	
	/*Print the data*/
	for (i = 0; i < 10; i ++) {
		printf ("%d ", buf[i]);
	}

	for (i = 0; i < 10; i ++) {
		buf [i] = 0;
	}

	/*Write data to shared memory*/
	if (write (shm, buf, sizeof(int) * MAX) == -1) {
		perror ("Write : ");
	}
	/*Once writing is done release the semaphore*/
	if (sem_post (my_sem) == -1) {
		perror ("Semaphore post : ");
		return -1;
	}

	/*If semaphore is free the remove the named semaphore*/
	if (sem_wait (my_sem) == -1) {
		perror ("Semaphore post : ");
		return -1;
	}
	sem_unlink("/my_sem");

	if (sem_post (my_sem) == -1) {
		perror ("Semaphore post : ");
		return -1;
	}

	printf ("\n");

	return 0;
}
