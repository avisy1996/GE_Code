/*	Name: swap_nodes.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Swap the two nodes of linked list
*/
#include "sll.h"

Node *swap_nodes (Node *head, int no1, int no2)
{
	Node *node1 = head;
	Node *node2 = head;
	Node *prev1 = NULL;
	Node *prev2 = NULL;
	Node *temp = NULL;
	/*Find the pos of no1 and no2 in list*/
	while (node1 != NULL && node2 != NULL && 
			(node1 -> data != no1 || node2 -> data != no2)) {
		/*This will be true until no1 is not found in list*/
		if (node1 -> data != no1) {
			prev1 = node1;
			node1 = node1 -> next;
		}
		/*This will be true until no2 is not found in list*/
		if (node2 -> data != no2) {
			prev2 = node2;
			node2 = node2 -> next;
		}
	}
	//No1 or No2 is not present in list
	if (node1 == NULL || node2 == NULL) {
		return head;
	}

	if (prev1 == NULL) {	//Node1 is first node of list
		head = node2;
	}
	else {	//Node1 is not first node of list
		prev1 -> next = node2;
	}
	if (prev2 == NULL) {	//Node2 is first node of list
		head = node1;
	}
	else {	//Node2 is not first node of list
		prev2 -> next = node1;
	}

	//Swap the nodes	
	temp = node1 -> next;
	node1 -> next = node2 -> next;
	node2 -> next = temp;
	
	return head;
}
