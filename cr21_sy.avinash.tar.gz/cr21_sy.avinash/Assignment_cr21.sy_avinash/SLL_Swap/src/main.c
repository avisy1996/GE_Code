/*	Name: main.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Take then input from user and call divide list to even odd based on choice
*/
#include "sll.h"

int main (void) 
{
	Node *head = NULL;
	char str_ch[MAX];
	int ch, no1, no2;


	while (1) {
		printf ("1. Insert Node\n2. Swap nodes\n3. Display\n\
4. Exit\nEnter your choice : ");
		if (fgets (str_ch, MAX, stdin) == NULL) {
			perror ("fgets failed");
			return -1;
		}

		ch = my_atoi (str_ch);
		
		switch (ch) {
			case 1:
				head = insert_begin (head);
				break;
			case 2:
				/*Take first no as input*/
				printf ("Enter 1st No : ");
				if (fgets (str_ch, MAX, stdin) == NULL) {
					perror ("fgets failed");
					return -1;
				}
				no1 = my_atoi (str_ch);
				/*Take second no as input*/
				printf ("Enter 2nd No : ");
				if (fgets (str_ch, MAX, stdin) == NULL) {
					perror ("fgets failed");
					return -1;
				}
				no2 = my_atoi (str_ch);

				head = swap_nodes (head, no1, no2);	//Call swap nodes function
				break;
			case 3:
				printf ("List : ");	
				display_list (head);	//Display list
				break;
			case 4:
				exit(0);
				break;
			default:
				printf ("Wrong choice\n");
		}
	}
	return 0;
}
