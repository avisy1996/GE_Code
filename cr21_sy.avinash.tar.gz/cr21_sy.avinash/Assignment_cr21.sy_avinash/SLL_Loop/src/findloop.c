/*	Name: findloop.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Find loop in linked list using slow and fast pointer
*/
#include "sll.h"

/*If loop is found then count length of loop*/
static int loop_length (Node *node) 
{
	Node *temp = node;
	int count = 1;
	/*increment count until temp next is not node*/
	while (temp -> next != node) {
		count ++;
		temp = temp -> next;
	}

	return count;	//Return count
}
/*Find the loop in list*/
int findloop (Node *head)
{
	Node *slow_ptr = head;
	Node *fast_ptr = head;

	while (slow_ptr != NULL && fast_ptr != NULL && fast_ptr -> next != NULL) {
		slow_ptr = slow_ptr -> next;		//Slow pointer will point to next of slow_ptr
		fast_ptr = fast_ptr -> next -> next;	//Fast poitner will point to by next of next
		
		/*If slow_ptr and fast_ptr are same then there is loop in list*/
		if (slow_ptr == fast_ptr) {
			return loop_length (slow_ptr);	//Return count
		}
	}
	
	return 0;	//Return 0 if no loop present
}
