#ifndef _SLL_H
#define _SLL_H 1

#include <stdio.h>
#include <stdlib.h>
#define MAX 32

typedef struct Node{
	int data;
	struct Node *next;
} Node;

int findloop (Node *head);
Node *create_node (void);
int my_atoi (char *str);

#endif
