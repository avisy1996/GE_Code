/*	Name: main.c
*	Author: Avinash Yadav
*	Date of Creation: 21/08/2018
*	Description: file with main() function take filename as input and call word_count function.
*/
#include "word_count.h"

int main (void)
{
    FILE *fp;
    char *filename;
    int wc;

    filename = (char *) malloc (sizeof(char) * MAX);
    if (filename == NULL) {
        perror ("Malloc failed\n");
    }

    printf ("Enter filename : ");
    if (fgets (filename, MAX, stdin) == NULL) {
        printf ("Enter filename\n");
    }
    filename = str_tok (filename, "\n"); //Remove the new line char (\n) from the string
    fp = fopen (filename, "r");		//Open file in read mode
    if (fp == NULL) {
        perror ("Cannot open file");
        return -1;
    }

	/*Call word_count function*/
    wc = word_count (fp);

	/*if word count is 0 or more display
	* else print failed
	*/
    if (wc >= 0) {
        printf ("Word count = %d\n", wc);
    }
    else {
        printf("Failed\n");
    }

    free (filename);
    return 0;
}
