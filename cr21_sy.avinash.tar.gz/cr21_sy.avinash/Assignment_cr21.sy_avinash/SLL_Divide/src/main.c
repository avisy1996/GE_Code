/*	Name: main.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Take then input from user and call divide list to even odd based on choice
*/
#include "sll.h"

int main (void) 
{
	Node *head = NULL;
	Node *even_head = NULL;
	Node *odd_head = NULL;
	char str_ch[MAX];
	int ch;


	while (1) {
		printf ("1. Insert Node\n2. Divide list into Even Odd pos\n\
3. Exit\nEnter your choice : ");
		if (fgets (str_ch, MAX, stdin) == NULL) {
			perror ("fgets failed");
			return -1;
		}

		ch = my_atoi (str_ch);
		
		switch (ch) {
			case 1:
				head = insert_begin (head);	//insert node at the begin of list
				break;
			case 2:
				head = divide_list (head, &even_head, &odd_head);	//Divide list by even and odd positions
				printf ("Even pos list : ");
				display_list (even_head);
				printf ("Odd pos list : ");
				display_list (odd_head);
				break;
			case 3:
				exit(0);
				break;
			default:
				printf ("Wrong choice\n");
		}
	}
	return 0;
}
