/*	Name: divide_list.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Divide the list to even and odd based on node position
*/
#include "sll.h"

Node *divide_list (Node *head, Node **even_head, Node **odd_head)
{
	Node *temp = head;
	Node *even_temp = NULL;
	Node *odd_temp = NULL;
	int pos = 1;

	while (temp != NULL) {
		head = temp -> next;	
		temp -> next = NULL;
		/*If position is even*/
		if (pos % 2 == 0) {
			if (*even_head == NULL) {	//No nodes in even list
				*even_head = temp;
			}
			else {	//Nodes are present in even list
				even_temp -> next = temp;
			}
			even_temp = temp;
		}
		/*If position is odd*/
		else {
			if (*odd_head == NULL) {	//No nodes in odd list
				*odd_head = temp;
			}
			else {	//Nodes are present in odd list
				odd_temp -> next = temp; 
			}
			odd_temp = temp;
		}
		temp = head;
		pos ++;
	}
	return head;
}

