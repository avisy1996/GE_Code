/*	Name: create_node.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Take the input no and create the new node
*/
#include "sll.h"

Node *create_node(void)
{
	int data = 0;
	char str_data[MAX];
	Node *temp = NULL;
	/*Take the input number*/	
	printf("Enter The Data : ");
	if (fgets (str_data, MAX, stdin) == NULL) {
		 perror ("fgets failed");
		 return NULL; 
	}

	data = my_atoi (str_data);
	/*Create the node and add data to the node*/
	if(NULL == (temp = (Node *)malloc(sizeof(Node)))){
		printf("Malloc Is failed...\n");
	}
	else{
		temp -> data = data;
		temp -> next = NULL;
	}
	return temp;
}
