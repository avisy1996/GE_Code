#ifndef _WORD_COUNT_H
#define _WORD_COUNT_H 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUFFER_SIZE 1000
#define MAX 100

void replace_words (char *str, char *old_word, char *new_word);
char *str_tok (char *str, char *delim);
int str_len (char *str);
char *str_cat (char *str1, char *str2);
void str_cpy (char *dbuf, char *sbuf);
char *str_str (char *str, char *substr);

#endif
