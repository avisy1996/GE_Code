/*	Name: replace_words.c
*	Author: Avinash Yadav
*	Date of Creation: 21/08/2018
*	Description: function replace_words take the one line from file as input and replace old_word with new_word
*/
#include "replace_word.h"

void replace_words (char *str, char *old_word, char *new_word) 
{
	char *pos = NULL;
	char *search_ptr = NULL;
	char temp [BUFFER_SIZE];
	int i = 0;
	int ow_len, nw_len, len;

	/*find length of oldword and newword*/
	ow_len = str_len (old_word);
	nw_len = str_len (new_word);
	/*search_ptr is for updating pointer to the end of perticular word after replacement in str*/
	search_ptr = str;

	/*Find start of the word using str_str*/
	while ((pos = str_str (search_ptr, old_word)) != NULL) {
		str_cpy (temp, str);	//copy line to temp for backup

		i = pos - str;		//find index of old word
		
		str [i] = '\0';		//end line at that index by \0
		len = str_len (str);	//find length of line upto index i
		str_cat (str, new_word);	//Concatinate new word to str

		str_cat (str, temp + i + ow_len);	//concatinate remaining line after old word from temp to str
		
		search_ptr = search_ptr + nw_len + len;	//make search_ptr point to end of replaced new word
	}
}
