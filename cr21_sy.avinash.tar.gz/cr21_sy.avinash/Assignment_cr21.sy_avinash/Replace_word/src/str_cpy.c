#include "replace_word.h"

void str_cpy (char *dbuf, char *sbuf)
{
    while  ((*dbuf++ = *sbuf++) != '\0')
        ;

	*dbuf = '\0';
}
