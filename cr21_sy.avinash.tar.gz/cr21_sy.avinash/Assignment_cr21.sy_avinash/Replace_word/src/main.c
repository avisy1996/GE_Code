/*	Name: main.c
*	Author: Avinash Yadav
*	Date of Creation: 21/08/2018
*	Description: file with main() function take filename, word to find and replacement word as input.
*		Read the lines from file and call replace_words function to replace the word with new word.
*/

#include "replace_word.h"

int main (void)
{
    FILE *fp = NULL;
	FILE *ftemp = NULL;
    char *filename = NULL;
	char *tempfile = "temp.txt";
	char *newword = NULL;
	char *oldword = NULL;
	char line[BUFFER_SIZE];

    filename = (char *) malloc (sizeof(char) * MAX);
    newword = (char *) malloc (sizeof(char) * MAX);
	oldword = (char *) malloc (sizeof(char) * MAX);

	if (filename == NULL || newword == NULL || oldword == NULL) {
        perror ("Malloc failed\n");
    }

/*Get the filename*/
    printf ("Enter filename : ");
    if (fgets (filename, MAX, stdin) == NULL) {
        printf ("Enter filename\n");
    }
    filename = str_tok (filename, "\n"); //Remove newline character(\n) char from the string
    
	/*Open main file to read and one tempfile to write*/
	fp = fopen (filename, "r");
	ftemp = fopen (tempfile, "w");

    if (fp == NULL || ftemp == NULL) {
        perror ("Cannot open file");
        return -1;
    }
    printf ("Enter word to find : ");
    if (fgets (oldword, MAX, stdin) == NULL) {
        printf ("Enter filename\n");
    }
    oldword = str_tok (oldword, "\n"); //Remove newline character(\n) char from the string

    printf ("Enter Word to replace : ");
    if (fgets (newword, MAX, stdin) == NULL) {
        printf ("Enter filename\n");
    }
	newword = str_tok (newword, "\n"); //Remove newline character(\n) char from the string
	
	/*Call replace_words for each line and put new line after replacement in tempfile*/
	while ((fgets (line, BUFFER_SIZE, fp)) != NULL) {
		replace_words (line, oldword, newword);	
		fputs (line, ftemp);
	}
	/*Close both the files*/
	fclose (fp);
	fclose (ftemp);
	
	/*Again open tempfile in read mode and main file in writemode*/
	ftemp = fopen (tempfile, "r");
	fp = fopen (filename, "w");

    if (fp == NULL || ftemp == NULL) {
        perror ("Cannot open file");
        return -1;
    }
	/*Write data from tempfile to main file*/
	while ((fgets (line, BUFFER_SIZE, ftemp)) != NULL) {
		fputs (line, fp);
	}
	/*Close both the files*/
	fclose (fp);
	fclose (ftemp);
	remove (tempfile); 	//Remove tempfile
    free (oldword);
    free (newword);
    free (filename);
    return 0;
}
