#ifndef _SLL_H
#define _SLL_H 1

#include <stdio.h>
#include <stdlib.h>
#define MAX 32

typedef struct Node{
	int data;
	struct Node *next;
} Node;

Node *reverse_list (Node *head);
Node *insert_begin (Node *head);
Node *create_node (void);
int my_atoi (char *str);
void display_list (Node *head);

#endif
