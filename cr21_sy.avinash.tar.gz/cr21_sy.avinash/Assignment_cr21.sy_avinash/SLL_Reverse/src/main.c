/*	Name: main.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Take then input and call reverse_list function.
*/
#include "sll.h"

int main (void) 
{
	Node *head = NULL;
	char str_ch[MAX];
	int ch;


	while (1) {
		printf ("1. Insert Node\n2. Reverse Linked List\n3. Display\n\
4. Exit\nEnter your choice : ");
		if (fgets (str_ch, MAX, stdin) == NULL) {
			perror ("fgets failed");
			return -1;
		}

		ch = my_atoi (str_ch);
		
		switch (ch) {
			case 1:
				head = insert_begin (head);
				break;
			case 2:
				head = reverse_list (head);	//Reverse the list
				break;
			case 3:
				printf ("List : ");
				display_list (head);		//Display the list
				break;
			case 4:
				exit(0);
				break;
			default:
				printf ("Wrong choice\n");
		}
	}
	return 0;
}
