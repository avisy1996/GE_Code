/*	Name: reverse_list.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Reverse the linked list update the node pointers not data
*/
#include "sll.h"

Node *reverse_list (Node *head)
{
	Node *prev = NULL;
	Node *next = NULL;
	Node *cur = head;

	/*Repeat until cur is not null*/
	while (cur != NULL) {
		next = cur -> next;	//Make next point to next node of current
		cur -> next = prev;	//Remove link from cur to next and create link from cur to prev
		prev = cur;		//make prev point to cur
		cur = next;		//make cur point to next
	}
	return prev;		//Prev will be new head so return prev
}
