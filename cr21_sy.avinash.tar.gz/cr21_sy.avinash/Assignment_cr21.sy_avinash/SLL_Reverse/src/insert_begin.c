/*	Name: insert_begin.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Insert the node at begining of list.
*/
#include "sll.h"

Node *insert_begin(Node *head)
{
	Node *temp = create_node(); //Create new node
	if (temp == NULL) {	//if No node created
		return NULL;
	}
	else if(head == NULL) {	//if list is empty
		head = temp;
	}
	else{	//list contains the node
		temp -> next = head;
		head = temp;
	}
	return head;
}

