/*	Name: display_list.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Display data of linked list
*/
#include "sll.h"

void display_list(Node *head)
{
	Node *temp = head;
	if (head == NULL)
		printf("\nLinked List is empty\n");
	else{
		/*Until node points to null*/
		while (temp != NULL) {
			if (temp -> next != NULL) {	//If node is not last node
				printf("%d -> ",temp -> data);
			}
			else {	//If node is last node
				printf("%d",temp -> data);
			}
			temp = temp -> next;
		}
		printf ("\n\n");
	}
	return;
}
