#ifndef _WORD_OCCURENCE_H
#define _WORD_OCCURENCE_H 1

#include <stdio.h>
#include <stdlib.h>
#define MAX_WORDS 1000
#define MAX 100

int word_count (FILE *fp);
char *str_tok (char *str, char *delim);
int str_cmp (char *str1, char *str2);
void str_cpy (char *dbuf, char *sbuf);
int str_len (char *str);
void str_lwr (char *str);
int word_occurence (FILE *fp, char words[MAX_WORDS][MAX], int count[MAX_WORDS]);

#endif
