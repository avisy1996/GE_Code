#include "word_occurence.h"

void str_lwr (char *str) 
{
	int diff = 'a' - 'A';
	while (*str != '\0') {
		if (*str >= 'A' && *str <= 'Z') {
			*str = *str + diff;
		}
		str ++;
	}
}
