/*	Name: remove_duplicates.c
*	Author: Avinash Yadav
*	Date of Creation: 19/08/2018
*	Description: Remove duplicates from list
*/
#include "sll.h"

Node *remove_duplicate (Node *head)
{
	Node *prev = NULL;
	Node *temp = NULL;
	Node *cur = head;

	while (cur -> next != NULL) {
		prev =  cur;
		cur = cur -> next;
		/*if cur data is equal to data of cur's next then delete cur's next*/
		while (prev -> data == cur -> data) {	
			temp = cur;
			prev -> next = temp -> next;
			cur = temp -> next;
			free (temp);
		}
	}

	return head;
}
